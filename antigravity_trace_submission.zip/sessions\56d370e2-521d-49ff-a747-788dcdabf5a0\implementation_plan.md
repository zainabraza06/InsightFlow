# Implementation Plan - Billing & Mess-Off Refinement

Refining the monthly challan system with dynamic pricing, Stripe integration, and improved mess-off request handling for multi-month spans.

## User Review Required

> [!IMPORTANT]
> **Refined Mess-Off Logic**: Mess-off requests spanning multiple months will now have days counted separately for each month. The 12-day cap will be enforced per month. A request must be for **more than 1 day** (at least 2 inclusive days) to be valid.

## Proposed Changes

### Billing & Pagination

#### [MODIFY] [billingController.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/backend/controllers/billingController.js)
- **Dynamic Fee**: Calculate `baseMessFee` as `580 * days_in_month`.
- **Discount Threshold**: Ensure `messOffDiscount` is only applied if the total approved mess-off days for that month is **strictly greater than 1**.
- **Calculation**: If total > 1, `discount = total * 580`. Otherwise, `discount = 0`.
- **Stripe**: Real Stripe Test SDK integration for payments.

#### [MODIFY] [ChallanCard.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/components/billing/ChallanCard.tsx)
- Integrated Stripe `Elements` and `CardElement` for real test payments.

#### [NEW] [Bills Page](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/hostelite/bills/page.tsx)
- Dedicated paginated view for all monthly challans.

---

### Refined Mess-Off Logic

#### [MODIFY] [requestController.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/backend/controllers/requestController.js)
- **Min Duration**: Accept requests only if total inclusive duration is **at least 2 days**.
- **Mess-Off Count**: The actual mess-off days are calculated as **Inclusive Days - 1** (the first day of the range is never counted).
- **Multi-Month Split**: Correctly distribute the remaining days into `approvedDaysPerMonth` by skipping the first calendar day of the request.
- **Per-Month Capping**: Enforce the **12-day limit individually for each month**.

## Verification Plan

### Automated Tests
- Seed script simulation for multi-month requests (e.g., Feb 28 to March 5).
- Verify `approvedDaysPerMonth` contents in MongoDB.

### Manual Verification
1. Login as Hostelite.
2. Submit a mess-off request from Feb 28 to March 1 (2 days).
3. Verify it is accepted and split as 1 day in Feb, 1 day in March.
4. Attempt to submit a request for > 12 days in a single month and verify capping/rejection logic.
5. Verify that a 1-day request (same start and end date) is rejected.
