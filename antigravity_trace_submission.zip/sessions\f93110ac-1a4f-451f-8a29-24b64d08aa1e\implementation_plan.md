# Frontend Redesign Plan: 3D Animations & Responsiveness

This plan outlines the steps to modernize the frontend of "Reon", specifically targeting the Landing Page to include high-quality 3D animations and a responsive, glassmorphism-based design.

## User Review Required
> [!IMPORTANT]
> This plan involves replacing the existing `HomePage.module.css` with Tailwind CSS utility classes. The visual style will be significantly upgraded, which may differ from the current look.

## Proposed Changes

### Dependencies
- Install `framer-motion` for UI transitions.
- Install `@react-three/fiber`, `@react-three/drei`, `three` for 3D elements.
- Install `maath` for math helpers (optional but good for random 3D positioning).

### Component Architecture

#### [NEW] `components/3d/BackgroundScene.tsx`
A reusable 3D background component containing:
- A `Canvas` from `@react-three/fiber`.
- Floating 3D shapes (Spheres, Torus) with glass/transmission materials.
- Mouse interaction (parallax effect).
- Stars or particles field to replace the CSS particles.

#### [MODIFY] `components/HomePage.tsx`
- Remove import of `HomePage.module.css`.
- Refactor entire layout to use Tailwind CSS.
- Implement `framer-motion` for:
  - Hero text typing effect (staggered character animation).
  - Button hover states (scale/glow).
  - Feature cards entrance animations.
- Integrate `<BackgroundScene />` as a fixed background.
- Ensure Mobile-First Responsive Design using Tailwind's `md:`, `lg:` prefixes.

#### [MODIFY] `components/auth/login/LoginPage.tsx` & `SignUpPage.tsx`
- Remove CSS modules.
- Use `BackgroundScene` for consistency.
- Implement Glassmorphism for forms (`bg-white/10`, `backdrop-blur-md`).
- Ensure responsive layout.

#### [MODIFY] `components/chat/ChatPage.tsx`
- Replace `ChatPage.module.css` w/ Tailwind.
- Apply a darker, subtler version of `BackgroundScene` or gradient.
- Make Sidebar and ChatWindow containers semi-transparent to blend with the theme.

#### [MODIFY] `app/globals.css`
- Add utility classes for glassmorphism if needed (though Tailwind `backdrop-blur` works well).
- Ensure body background matches the 3D scene's tone.

#### [DELETE] `components/HomePage.module.css`
- No longer needed after refactor.
#### [DELETE] `components/auth/login/LoginPage.module.css`
#### [DELETE] `components/chat/ChatPage.module.css`

## Verification Plan

### Automated Tests
- Run `npm run lint` to check for style issues.
- Build the project (`npm run build`) to ensure no type errors with new libraries.

### Manual Verification
- validte the Landing Page on Desktop (1920x1080).
- Validate the Landing Page on Mobile (iPhone SE/XR dimensions).
- Check performance (fps) of the 3D scene.
- Verify navigation to Login/Signup still works.
