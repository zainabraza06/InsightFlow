# Implementation Plan: Emergency Contact Information Integration

This plan details the addition of emergency contact information to the registration flow for all user roles (Patient, Doctor, Admin).

## Proposed Changes

### [Backend]

#### [MODIFY] [User.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/models/User.js)
- Add new fields:
    - `emergency_contact_name`: String
    - `emergency_contact_phone`: String
    - `emergency_contact_email`: String
    - `emergency_contact_relationship`: String

#### [MODIFY] [authService.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/services/authService.js)
- Update `registerPatient`: Extract and save emergency contact fields to the `User` document.
- Update `registerDoctor`: Extract and save emergency contact fields to the `User` document.
- Update `registerAdmin`: Extract and save emergency contact fields to the `User` document.

#### [MODIFY] [adminService.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/services/adminService.js)
- Update `registerDoctorAsAdmin`: Ensure emergency contact fields are handled when an admin creates a doctor account directly.

### [Frontend]

#### [MODIFY] [page.tsx (register)](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/register/page.tsx)
- Add emergency contact fields to `formData` state.
- Add UI section for "Emergency Contact" with fields: Name, Phone, Email, and Relationship.
- Update `handleSubmit` to include these fields in the registration payload.

#### [MODIFY] [page.tsx (add-admin)](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/admin/add/page.tsx)
- Current UI already has the fields, but they are not being sent.
- Update `handleSubmit` to include the `emergencyContactName`, `emergencyContactPhone`, `emergencyContactEmail`, and `emergencyContactRelationship` in the `adminData` payload sent to the backend.

## Verification Plan

### Automated Tests
- Postman/Fetch tests to verify that registration endpoints accept and store emergency contact data.

### Manual Verification
- Register a new **Patient**: Fill out emergency contact and verify in database.
- Register a new **Doctor**: Fill out emergency contact and verify in database.
- Create an **Admin**: Fill out emergency contact and verify in database.
- Create a **Doctor via Admin**: Fill out emergency contact and verify in database.
