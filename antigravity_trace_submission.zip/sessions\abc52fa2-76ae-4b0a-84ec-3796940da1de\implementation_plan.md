# 24h Rule & Doctor Emergency Flow

## Changes
- **Backend**:
  - Update `MIN_PATIENT_CANCEL_HOURS` & `MIN_DOCTOR_CANCEL_HOURS` to 24.
  - `rescheduleAppointmentByPatient`: Auto-confirm if PAID.
  - New Model: `DoctorEmergencyRescheduleRequest`.
  - Service Functions: `requestDoctorEmergencyReschedule`, `approveDoctorEmergencyReschedule`, `getDoctorEmergencyRequests`.
- **Frontend**:
  - Doctor Appointment Page: Show "Emergency Reschedule" option if < 24h.
  - Admin Page: View and Approve requests (Status -> RESCHEDULE_REQUESTED).

## Verification
1.  **Patient Cancellation**: Try canceling confirmed appointment < 24h. Should fail (toast error).
2.  **Doctor Cancellation**: Try canceling confirmed appointment < 24h. Should prompt for Emergency Request.
3.  **Doctor Emergency**: Submit request -> Admin approves -> Patient Reschedule Logic.
4.  **Rescheduling**: Patient reschedules paid appointment -> Status becomes CONFIRMED instantly.
