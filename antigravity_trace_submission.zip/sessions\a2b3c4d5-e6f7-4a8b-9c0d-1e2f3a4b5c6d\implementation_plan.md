# Implementation Plan: Data Ingestion Agents (May 16)

## 🎯 Goal
Build the initial phases of the pipeline: URL Scraping, PDF Parsing, and CSV Extraction.

## 🤖 Agent Definitions
1.  **Ingestion Manager**: Coordinates input types.
2.  **Web Crawler**: Extracts text from URLs.
3.  **Document Parser**: Extracts structured text from PDFs/CSVs.

## 📝 Tasks
- [x] Implement PDF text extraction logic.
- [x] Implement BeautifulSoup web scraping.
- [x] Create unified API endpoint `/api/analyze` to receive multi-format input.
- [x] Test ingestion with sample policy updates and dashboards.
