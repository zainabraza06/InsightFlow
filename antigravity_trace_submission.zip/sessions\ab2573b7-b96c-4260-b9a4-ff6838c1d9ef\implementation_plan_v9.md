# Implementation Plan: Role-based Navbar & Header Consistency

This plan synchronizes the navigation and header aesthetics across all user roles (Admin, Doctor, Patient) to ensure a unified "Healix Premium" experience.

## Proposed Changes

### [Frontend Components]

#### [MODIFY] [Navbar.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/components/Navbar.tsx)
- Harmonize Navigation Labels:
    - Change "Visits" to "Appointments" for Patients and Doctors.
    - Change "Stats" to "Daily Vitals" for Patients.
- Update icon colors and hover states to be even more consistent with the "Emerald/Teal" theme.
- Refine the User Profile area with a clearer status badge.

### [Patient Dashboard]

#### [MODIFY] [page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/patient/dashboard/page.tsx)
- Integrate 3D Environment: Add `Scene` and `FloatingIcons` background components.
- Upgrade Header:
    - Shift to `text-5xl font-black` high-fidelity typography.
    - Add gradient clipping for the primary welcome message.
    - Replace standard summary with a refined Activity/Alert summary line.
- Modernize Stats: Apply premium glassmorphism to vitals cards.

### [Doctor Dashboard]

#### [MODIFY] [page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/doctor/dashboard/page.tsx)
- Polish Header: Increase font weight and adjust tracking to match the latest Admin style.
- Refine Navigation: Update any internal dashboard links to match the new "Appointments" labeling.

## Verification Plan

### Manual Verification
- Log in as **Patient**: Verify 3D background presence and upgraded header typography.
- Log in as **Doctor**: Verify updated navbar labels and refined header.
- Log in as **Admin**: Ensure the navbar remains consistent with the other roles.
- Cross-check "Appointments" labelling on all mobile and desktop views.
