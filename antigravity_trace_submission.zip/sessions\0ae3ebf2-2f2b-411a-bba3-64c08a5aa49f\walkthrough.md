# Complaints System Walkthrough

I have implemented a comprehensive complaints management system that allows hostelites to report issues and managers to efficiently track and resolve them.

## Changes Made

### Backend
- **[NEW] [Complaint.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/backend/models/Complaint.js)**: Mongoose model representing a complaint with fields for title, description, category (Plumbing, Electrical, etc.), status, and manager comments.
- **[NEW] [complaintController.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/backend/controllers/complaintController.js)**: Logic for submitting, retrieving, and resolving complaints.
- **[NEW] [complaintRoutes.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/backend/routes/complaintRoutes.js)**: API endpoints for complaints.
- **[MODIFY] [server.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/backend/server.js)**: Registered the new complaint routes.

### Frontend
- **[MODIFY] [constants.ts](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/utils/constants.ts)**: Added complaint-related API endpoints and status constants.
- **[MODIFY] [api.ts](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/services/api.ts)**: Implemented `complaintService` for API interaction.
- **[MODIFY] [hosteliteDashboardPage](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/hostelite/dashboard/page.tsx)**: Added a new `StatCard` to show "Remaining Mess-Off Days" with a progress indicator for the 12-day monthly limit.
- **[NEW] [Hostelite Complaints Page](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/hostelite/complaints/page.tsx)**: User interface for hostelites to submit and track their complaints.
- **[NEW] [Manager Complaints Page](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/manager/complaints/page.tsx)**: Dashboard for managers to view, comment on, and resolve complaints.
- **[MODIFY] [Navbar.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/components/Navbar.tsx)**: Added "Complaints" link to the main navigation for both hostelites and managers.

## Features

### Hostelite Experience
- **Submit Complaint**: Form to report issues with category selection and detailed description.
- **Track Status**: Real-time updates on complaint status (Pending, In Progress, Resolved).
- **View Manager Response**: See comments provided by the manager regarding the resolution.

### Manager Experience
- **Centralized Dashboard**: View all complaints filed for the managed hostel.
- **Update Status**: Transition complaints through different stages of resolution.
- **Add Comments**: Provide feedback or explanations to the hostelite.

## Verification Results
- Backend routes are secured and restricted by role.
- Frontend pages are fully responsive and follow the application's glassmorphism design language.
- Navigation links correctly route users to their respective complaint dashboards.
- Error handling is standardized across all new components.

## Bug Fixes
- **Manager Complaints Retrieval (400 Error)**: Fixed a bug where `/api/complaints/all` returned a 400 error due to missing `hostelId` in the JWT payload. The controller now fetches the manager's hostel association directly from the database.

## UX Improvements
- **Complaint Resolution Control**: Managers can no longer see the "Update Status" option for complaints that are already marked as `RESOLVED`, preventing accidental updates.
- **Pagination**: Added backend and frontend pagination to the Manager Complaints dashboard to handle large volumes of complaints efficiently.

## Admin Monitoring System
I have added a powerful **Admin Role** with global monitoring capabilities. Administrators can now oversee the entire system from a dedicated dashboard.

### Features
- **Global Overview**: Real-time statistics on total users, hostels, complaints, and requests system-wide.
- **Global Complaints**: View and filter every complaint filed in any hostel.
- **Global Requests**: Monitor all leave, cleaning, and mess-off requests system-wide.
- **Hostel Oversight**: Centralized view of all hostels, occupancy rates, and assigned managers.
- **User Oversight**: High-level view of all system users (Hostelites, Managers, Staff).

### Key Pages
- **[Admin Dashboard](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/admin/dashboard/page.tsx)**: The command center for the entire system.
- **[Global Complaints](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/admin/complaints/page.tsx)**: Global issue tracking.
- **[Global Requests](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/admin/requests/page.tsx)**: Global request monitoring.
- **[Hostel Management](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/admin/hostels/page.tsx)**: Oversight of all hostel properties.

## Billing & Occupancy System
Enhanced oversight for financial and occupancy data.

### Features
- **Manager Occupancy Rate**: Real-time occupancy percentage now visible on the Manager Dashboard.
- **Global Billing (Admin)**: A centralized window to monitor all student challans across all hostels, with status and month filtering.
- **Hostel Billing (Manager)**: Managers can now oversee challans specifically for students in their assigned hostel.
- **Navbar Integration**: Direct "Billing" access for both Admins and Managers.
- **Student Filtering**: Both Admins and Managers can filter challans by student.
- **Enhanced Billing Filters**: Standardized filter UI across Admin, Manager, and Student pages with explicit labels and reset functionality.
- **Enhanced Billing Filters**: Standardized filter UI across Admin, Manager, and Student pages with explicit labels and reset functionality.
- **Automatic Overdue Logic**: Unpaid challans are now automatically marked as "OVERDUE" once their due date passes.
- **Student-Side Filters**: Students can now filter their personal bill history by status and month.
- **Admin Student Dropdown Fix**: Implemented a dedicated `getAllHostelitesGlobal` endpoint for Admins to fetch all students, resolving access issues.
- **Manager Data Verification**: Verified that Managers only see students assigned to their specific hostel.

## Admin Registration
An initial administrator account has been created for system bootstrapping.

- **Admin Email**: `admin@nhms.edu.pk`
- **Password**: `AdminPassword123!`
- **Access Level**: `SUPER_ADMIN`

Administrators can use these credentials to log in and access the global monitoring systems.
