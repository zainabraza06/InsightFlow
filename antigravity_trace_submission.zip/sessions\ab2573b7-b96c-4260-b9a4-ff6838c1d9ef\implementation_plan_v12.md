# Implementation Plan: Interactive Vitals Visualization

This plan details the enhancement of the Patient Dashboard with dynamic, high-fidelity vitals charts.

## Proposed Changes

### [Backend]

#### [MODIFY] [patientService.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/services/patientService.js)
- Ensure `getVitalsHistory` correctly filters and returns all relevant fields (`heartRate`, `respiratoryRate`, `oxygenLevel`, etc.) for the requested number of days.

### [Frontend]

#### [MODIFY] [PatientDashboard](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/patient/dashboard/page.tsx)
- **Timeframe Selector**: Add a premium button group or dropdown to toggle between 7 Days, 30 Days, and 3 Months.
- **Dynamic Data Fetching**: Update local state and re-fetch vitals history whenever the timeframe changes.
- **Interactive Vitals Chart**:
    - Implement a main "Health Trend" chart area.
    - Add a vitals selector (checkboxes or chips) to toggle visibility of specific metrics (Heart Rate, BP, Oxygen, Temp, Respiratory Rate).
- **Refined Graphics**: Enhance `AreaChartWrapper` or create a new `VitalsTrendChart` component with better tooltips and multi-line support.

## Verification Plan

### Automated Tests
- Verify `apiClient.getVitalsHistory` with different `days` parameters.

### Manual Verification
- Log in as **Patient**: 
    - Change timeframe and confirm charts update.
    - Toggle different vitals and confirm visibility changes.
    - Verify 3D background performance remains smooth during chart interactions.
