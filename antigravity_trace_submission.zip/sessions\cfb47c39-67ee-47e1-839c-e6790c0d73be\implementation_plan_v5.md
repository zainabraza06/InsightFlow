# fix-admin-modal-stacking

The goal is to resolve the issue where the navbar appears above Admin modals by porting them to a React Portal.

## Proposed Changes

### [Component Name] [GestureWeb Frontend]

#### [MODIFY] [AdminResearch.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/AdminResearch.js)
- Import `ReactDOM` from `react-dom`.
- Wrap the modal `AnimatePresence` in `ReactDOM.createPortal`, targeting the `modal-root` element in `index.html`.
- This will elevate the modal above the main application stacking context, including the fixed navbar.

## Verification Plan

### Manual Verification
- Open any Admin modal (e.g., "Add Area").
- Verify that the modal now covers the navbar completely.
- Ensure all modal interactions (close, save, cancel) still function as expected.
