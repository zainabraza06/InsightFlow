# Overhaul System Logs UI

This plan details the modernization of the Admin System Logs page with data visualization and a premium aesthetic.

## Proposed Changes

### [Component] Frontend: System Logs Page

#### [MODIFY] [admin/logs/page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/admin/logs/page.tsx)
-   **3D Background**: Integrate `Scene` and `FloatingIcons` for a dynamic feel.
-   **Glassmorphism**: Apply `glass-card` and `backdrop-blur` to the main containers.
-   **Data Visualization**:
    -   Add a **Log Distribution** chart (Pie Chart) showing levels (INFO, WARNING, ERROR).
    -   Add a **Recent Activity** trend chart (Bar Chart) showing logs over time (if data permits).
-   **Improved Header**: Modern typography and integrated download buttons with better styling.
-   **Better List Item**:
    -   Use the `getActivityIcon` and `getActivityColor` with more refined styles.
    -   Add hover effects and better spacing.
-   **Enhanced Search/Filter**: 
    -   Add a search bar for filtering descriptions/actions.
    -   Add level/action filters.
-   **Detail Panel**:
    -   Sticky detail panel with syntax highlighting for `additionalInfo`.
    -   Better key-value pair display.

### [Component] Backend: Admin Service (Optionally)

#### [MODIFY] [adminService.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/services/adminService.js)
-   Ensure logging includes `level` and `status` consistently (re-verify `Log` model).

---

## Verification Plan

### Manual Verification
1. **Visual Check**: Open `/admin/logs`, verify 3D background is active and cards are transparent/blurred.
2. **Charts**: Verify the log distribution pie chart accurately reflects the data on the first page.
3. **Filtering**: Type in the search box; verify the list filters instantly.
4. **Detail View**: Click a log; verify details appear in the right panel with formatted JSON if applicable.
5. **Downloads**: Test CSV, JSON, and PDF downloads.
