# fix-swipe-palm-confusion

The goal is to prevent the `open_palm` gesture (Open/Close Modal) from being accidentally triggered at the end of a swipe gesture.

## Proposed Changes

### [Component Name] [GestureWeb Frontend]

#### [MODIFY] [GestureControl.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/GestureControl.js)
- **Increase Post-Swipe Lockout**: 
    - Change the `movementCooldownRef.current` update after a swipe from `Date.now() - 100` to `Date.now()`.
    - Increase the static gesture debounce period after movement from `200ms` to `800ms`.
    - This gives the user nearly a full second to return their hand to a neutral position after a swipe before any "Open Palm" or "Point" gestures can be detected.

## Verification Plan

### Manual Verification
1. Navigate to Projects or Research.
2. Enable Card Mode (☝️).
3. Perform a rapid swipe (👈 or 👉) to move focus.
4. Verify:
    - The focused card changes correctly.
    - The modal **DOES NOT** open even if your fingers straighten out at the end of the swipe.
5. Perform a deliberate **Open Palm** (🖐️) while holding your hand still.
    - Verify the modal opens correctly after the short (~800ms) stability pause.
