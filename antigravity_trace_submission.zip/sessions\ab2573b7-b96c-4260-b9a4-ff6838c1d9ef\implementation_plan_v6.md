# Modernize Navbar and Pending Doctors UI

This plan details the UI overhaul for the global Navbar and the Admin Pending Doctors page to align with the premium 3D/glassmorphism aesthetic.

## Proposed Changes

### [Component] Global: Navbar

#### [MODIFY] [Navbar.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/components/Navbar.tsx)
-   **Glassmorphism**: Apply `bg-white/70 backdrop-blur-lg border-white/20`.
-   **Hover Effects**: Add subtle scale and gradient underlines for nav items.
-   **Active State**: Use a more vibrant gradient or distinct background for the active link.
-   **Typography**: Update fonts and sizes for a more premium look.
-   **Logo**: Refine the logo styling with a subtle glow or gradient.

### [Component] Admin: Pending Doctors Page

#### [MODIFY] [admin/pending-doctors/page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/admin/pending-doctors/page.tsx)
-   **3D Background**: Integrate `Scene` and `FloatingIcons`.
-   **Header Overhaul**: Larger, bolder typography with gradient accents.
-   **Card Redesign**:
    -   Enhance `glass-card` with better borders and shadows.
    -   Improve information hierarchy (vitals like Experience and Specialization as prominent badges).
    -   Add profile-like structure to the info layout.
-   **Action Buttons**: Use vibrant gradients and refined hover states.
-   **Modals**: Modernize approval/rejection modals with consistent glass styling and animations.
-   **Empty State**: Add a more visual "All Caught Up" illustration or better icon styling.

---

## Verification Plan

### Manual Verification
1.  **Navbar**: Check responsiveness and transparency while scrolling over page content.
2.  **Pending Doctors**:
    *   Verify 3D background is active.
    *   Check card layout and button interactions.
    *   Test approval/rejection modals and ensure they display generated IDs/passwords clearly.
3.  **Cross-role Check**: Verify Navbar works correctly for Patient and Doctor roles.
