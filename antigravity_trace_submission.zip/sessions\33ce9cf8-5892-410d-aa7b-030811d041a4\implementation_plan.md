# Add Visible Hand Cursor for Gesture Click Targeting

## Problem

Currently, the `point` (☝️) and `pinch` (🤏) gestures trigger a click at the **dead center** of the screen (`window.innerWidth / 2, window.innerHeight / 2`). The hand landmarks are only drawn on the small camera canvas inside the side panel — there is **no visible cursor on the main page** showing the user where a click will land. This makes gestures like "click" essentially useless because the user cannot aim.

## Proposed Changes

### GestureControl Component

#### [MODIFY] [GestureControl.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/GestureControl.js)

1. **Add a new callback prop `onCursorMove`** that reports the index finger tip position (landmark #8) mapped to screen coordinates on every frame
2. The mapping: MediaPipe gives normalized `(x, y)` in `[0, 1]`. We mirror X (since the camera is mirrored) and map to `window.innerWidth` / `window.innerHeight`

---

### App — Cursor State & Click at Cursor Position

#### [MODIFY] [App.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/App.js)

1. Add `cursorPosition` state `{ x, y, visible }` 
2. Pass `onCursorMove` callback to `GestureControl` that updates this state
3. **Fix `point` and `pinch` click**: dispatch the `MouseEvent` at `cursorPosition.x, cursorPosition.y` instead of the screen center
4. Render a new `<HandCursor />` component at the cursor position

---

### New: Hand Cursor Overlay Component

#### [NEW] [HandCursor.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/HandCursor.js)

A small circular/ring cursor that follows the hand's index finger tip across the entire page:
- Fixed-position overlay with `pointer-events: none`
- Smooth following via CSS transform
- Pulsing animation on click (point/pinch gesture)
- Color changes depending on state: idle (cyan glow), clicking (green flash)

#### [NEW] [HandCursor.css](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/HandCursor.css)

Styling for the cursor: glowing ring, pulse animation, smooth transitions.

## Swipe and Debounce Refinement

### GestureControl Stabilization

#### [MODIFY] [GestureControl.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/GestureControl.js)

1.  **Correct Swipe X-Axis Logic**: Swap `swipe_left` and `swipe_right` detection to account for camera mirroring (moving hand to user's right currently triggers `swipe_left`).
2.  **Improve Axis Dominance**: Change the diagonal swipe prevention to use a ratio (e.g., 1.5x) instead of simple comparison.
3.  **Implement Robust Debouncing**:
    *   Apply `debounceMs` to EVERY gesture (swipes and static).
    *   Add a specific repeat-gesture lockout to prevent multiple navigations from a single long motion.
4.  **Increase Stability Requirements**: Increase the number of frames required for a gesture to be considered "stable".

## Verification Plan

### Manual Verification

1. Run the app with `npm start`
2. Enable gestures
3. **Test Swipe Direction**: Verify that swiping your hand to YOUR right takes you to the NEXT page (standard UI pattern).
4. **Test Axis Separation**: Try swiping diagonally and verify that only the dominant axis triggers an action.
5. **Test Debounce**: Swipe once and ensure only ONE navigation event occurs even if the hand stays in motion for a split second.
6. **Verify Settings**: Check that the "Delay" slider in the side panel correctly affects how frequently gestures can trigger.
