# Walkthrough - Billing, Mess-Off & Testing Infrastructure

I have finalized the core billing logic, Stripe integration, and added a robust testing suite to ensure all business rules are enforced.

## 🧪 Testing Infrastructure
I have added standalone test scripts to verify the logic without needing a full database or server run.
- **Run Tests**: Execute `npm run test:logic` in the `backend` directory.
- **Verified Rules**:
    - **1st Day Skip**: Verified that a 2-day request counts as 1 day, and the first day is never counted towards discounts.
    - **Multi-Month Split**: Verified that days are correctly distributed across months.
    - **Billing Threshold**: Verified that a month only receives a discount if it has **> 1 approved day**.
    - **Capping**: Verified the 12-day mess-off discount limit.
    - **Dynamic Pricing**: Verified that March (31 days) and Feb (28 days) generate different base fees.

## 💳 Stripe Integration & Setup
The system requires real Stripe API keys to function. **If keys are missing, the payment section will show a setup warning.**

### Setup Instructions
1.  **Frontend**: Create a `.env` file in the `frontend` folder and add:
    ```env
    NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_your_real_key
    ```
2.  **Backend**: Create a `.env` file in the `backend` folder and add:
    ```env
    STRIPE_SECRET_KEY=sk_test_your_real_key
    ```
- **Test Card**: Use Stripe's default test card: `4242 4242 4242 4242` with any future date and 3-digit CVC.

### Troubleshooting
- **"Invalid API Key" error**: Ensure you have copied your *actual* keys from the [Stripe Dashboard](https://dashboard.stripe.com/test/apikeys) into your `.env` files.

## 🧾 Billing Recap

| component | Details |
| :--- | :--- |
| **Base Fee** | 580 PKR × Days in month. |
| **Mess-Off Discount** | 580 PKR/day. Skip the first day of the request. |
| **Monthly Cap** | Max 12 days discount per month. |
| **Discount Rule** | Month total must be **> 1 day** to get any discount. |
| **Penalty** | 1000 PKR for each unpaid previous month. |

## 📁 New Files
- `backend/tests/messOff.test.js`: Core duration and splitting logic tests.
- `backend/tests/billing.test.js`: Fee and discount calculation tests.
- `backend/.env.example`: Updated with Stripe key placeholders.
- `frontend/src/providers/StripeProvider.tsx`: Context provider for Stripe Elements.
