# NEXUS Command Center — Administrator Architecture & Telemetry console

The **NEXUS Admin Command Center** is a secure, state-of-the-art administrative platform built directly into the InsightFlow Next.js frontend and FastAPI backend. It provides 360° visibility into system executions, user registrations, budget allocations, and reinforcement learning telemetry.

---

## 🏗️ Technical Architecture & Telemetry Pipeline

```mermaid
graph TD
    UserClient[User Browser Session] -->|1. Submit Feedback & Rating| FastApiServer[FastAPI Orchestration Layer]
    FastApiServer -->|2. Persist feedback.json| FeedbackDb[(feedback.json Store)]
    
    AdminClient[Admin Session] -->|Request Dashboard Telemetry| AdminEndpoints[FastAPI /admin/dashboard-stats]
    AdminEndpoints -->|Read & Calculate| FeedbackDb
    AdminEndpoints -->|Read & Calculate| HistoryDb[(history.json Store)]
    AdminEndpoints -->|Read & Calculate| UsersDb[(users.json Store)]
    AdminEndpoints -->|Return Aggregated Stats JSON| AdminClient

    subgraph Reinforcement Loop
        ConsensusEngine[Consensus Debate Engine] -->|Retrieve domain tuning context| FeedbackDb
        ConsensusEngine -->|Inject learning instructions into Orion/Raven/Cipher prompts| LlmAgents[Gemini 2.0 Flash ADK Agents]
    end
```

---

## ⚡ Active Administrative Capabilities

### 1. Unified Telemetry Dashboard (Analytics HUD)
* **Registered Profiles Counter**: Dynamic counter reflecting all active database users.
* **Pipeline Executions Counter**: Totals the complete history of multi-source agent debate runs.
* **Aggregated Budget Spent**: Live counter aggregating the total financial cost of action chains in Pakistani Rupees (PKR).
* **Global System Rating**: Displays the rolling average satisfaction rating (out of 5 stars) from user feedbacks.

### 2. Tabular Operator Directory (Users Tab)
* **Privilege Level Badge**: Clearly labels users as either `Admin Partner` or `Platform User`.
* **Privilege Toggling Controls**: Allows admins to promote standard users or demote administrative accounts. Demoting your own logged-in profile is automatically blocked for safety.

### 3. Historical Debate Ledger (History Tab)
* **Granular Telemetry columns**: Tracks Operator Email, Timestamp, Domain, Topic, Contradictions Count, Actions total, Cost (PKR), and completion status.
* **Administrative Deletion**: Wipes specific run records instantly, immediately recalculating total system cost and budget metrics.

### 4. Reinforcement Commentary & Recalibration (Feedback Tab)
* **Sentiment Tags**: Highlights user satisfaction levels (★ 4-5 green, ★ 3 yellow, ★ 1-2 red).
* **Tuning Configs**: Displays the exact confidence map of Orion, Raven, and Cipher agents at the time of user review.
* **Purge & Recalibration**: A click triggers feedback wipeout and immediately returns agent debate prompts to standard system prompt baselines.

---

> [!NOTE]
> All administrative routes are protected by a client-side route guard, checking user attributes in JWT payloads, and a strict backend FastAPI dependency injection `check_admin` which returns HTTP 403 Forbidden on illegal access attempts.
