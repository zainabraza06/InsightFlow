# fix-gesture-sensitivity

The goal is to fix the recognition of `rock_on` (🤘) and `peace` (✌️) gestures by relaxing detection thresholds and reducing the intentional delay after movement.

## Proposed Changes

### [Component Name] [GestureWeb Frontend]

#### [MODIFY] [GestureControl.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/GestureControl.js)
- **Relax Thresholds**:
    - Lower `threshold` (extended fingers) from `0.65` to `0.6`.
    - Increase `bent` (folded fingers) from `0.6` to `0.7`.
- **Improve Peace Logic**:
    - Update `peace` check to use the updated `threshold` and `bent` constants for consistency.
- **Reduce Post-Movement Delay**:
    - Change `timeSinceMovement > 800` to `timeSinceMovement > 400`. 
    - This provides a much faster response (400ms half-second) while still filtering out swipe "aftershocks".

## Verification Plan

### Manual Verification
1. Navigate to Projects.
2. Enable Card Mode (☝️).
3. Perform **Peace** (✌️).
    - Verify: Navigation to Home.
4. Perform **Rock On** (🤘).
    - Verify: Modal opens.
5. Verify that these gestures trigger much faster than before (within ~0.4s of hand becoming still).
6. Verify that rapid swipes still don't trigger accidental selection.
