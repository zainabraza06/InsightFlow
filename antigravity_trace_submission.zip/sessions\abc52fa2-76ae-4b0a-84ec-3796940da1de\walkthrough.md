# Verification: 24h Cancellation Rule & Doctor Emergency Flow

## Overview
We enforced a 24-hour cancellation notice period for both Patients and Doctors. Doctors can request an **Emergency Reschedule** (via Admin) if within the 24h window.

## Changes Implemented
- **Backend**: Updated cancellation allowed window to > 24 hours.
- **Backend / Frontend**: Implemented "Doctor Emergency Reschedule Request" flow.
- **Frontend**: Created Admin Emergency Requests page.
- **Frontend**: Updated Patient "Cancel" logic to block if < 24h.

## Verification Steps

### 1. Patient Cancellation (< 24h)
1.  Log in as **Patient**.
2.  Find a confirmed appointment scheduled for **tomorrow (within 24h)**.
3.  Try to click **Cancel**.
4.  **Expected**: Blocked or Error Toast "Cannot cancel within 24 hours".

### 2. Doctor Cancellation (< 24h) & Emergency Request
1.  Log in as **Doctor**.
2.  Find the same appointment (or another within 24h).
3.  Click **Cancel**.
4.  **Expected**: A modal "Emergency Reschedule" appears (instead of direct cancel).
5.  Enter reason and Submit.
6.  **Expected**: Toast "Request sent to Admin".

### 3. Admin Approval
1.  Log in as **Admin**.
2.  Navigate to `/admin/emergency-requests`.
3.  Switch to **Doctor Reschedules** tab.
4.  Find the request from the doctor.
5.  Click **Approve**.
6.  **Expected**: Request marked approved. Appointment status changes to `RESCHEDULE_REQUESTED`.

### 4. Patient Rescheduling (Auto-Confirm)
1.  Log in as **Patient**.
2.  Check the appointment. Status should be `RESCHEDULE_REQUESTED` (Doctor Request).
3.  Click **Accept & Pick Time**.
4.  Select a new date.
5.  **Expected**: Appointment immediately **CONFIRMED** (no payment required if previously paid).
