# Hand Cursor & Click Targeting — Walkthrough

## Changes Made

### 1. Hand Cursor Overlay (New)
- [HandCursor.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/HandCursor.js) — Glowing ring cursor following index finger tip
- [HandCursor.css](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/HandCursor.css) — Cursor styling with breathing + click ripple animations

### 2. Fixed Click Targeting
- [App.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/App.js) — `point`/`pinch` now click at cursor position instead of screen center

### 3. Fixed Camera Reinitialization Bug (Root Cause)
- [GestureControl.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/GestureControl.js)
- **Stabilized Detection:** Increased smoothing and improved internal thresholds to prevent flickering recognition.
- **Improved Swipe Accuracy:** Corrected X-axis mirroring and added a 1.5x axis dominance ratio to filter out diagonal noise.
- **Unified Debounce:** The "Delay" setting now correctly applies to every gesture, including swipes.
- **Repeat Lockout:** Added a 50% extra cooldown for repeat gestures to prevent rapid accidental triggers.
- **Fixed Camera Display:** Resolved a race condition in video initialization and synced canvas/video dimensions for accurate landmark rendering.
- **Prevented Accidental Shutdowns:** Disabled the logic that allowed gestures to turn off the tracking system unexpectedly.

> [!IMPORTANT]
> The `onResults` function was a **plain inline function** listed in the `useEffect` dependency array. Each cursor position update → state change → re-render → new `onResults` → `useEffect` tears down and reinitializes the camera/hands. This **infinite loop** is why the camera wasn't visible and gestures weren't detected.

**Fix**: Wrapped `onResults` in `useCallback([], [])` and stored tunable settings (`swipeThreshold`, `debounceMs`, `minConfidence`) in refs. The camera `useEffect` now only depends on `[enabled]`.

## Verification
- ✅ Build compiles (`exit code 0`, no errors)
