# Tasks

- [x] Card Navigation & Auto-Scroll Fix
    - [x] Restore scrollIntoView logic for card focus
    - [x] Add unique IDs to project/research cards
    - [x] Refine initial focus logic (index 0 on first swipe)
    - [x] Add cardNavActive dependency to focus effects
    - [x] Verify full-library scrolling

- [x] MediaPipe WASM Stability Fix
    - [x] Move Hands initialization to global singleton scope
    - [x] Refine locateFile to prevent pack/wasm loading failures
    - [x] Remove all close() / cleanup logic that triggers WASM abort
    - [x] Verify multi-toggle stability

- [x] Admin Dashboard & Backend Auth
    - [x] Implement Backend Auth (Models, Controllers, Middleware, Routes)
    - [x] Add CRUD operations for Projects and Research
    - [x] Create Admin Frontend (Login, Dashboard, Management Pages)
    - [x] Protect Admin Routes with JWT
    - [x] Verify Data Persistence and Security

- [x] Enhance Error Feedback
    - [x] Update AdminProjects.js to show specific errors
    - [x] Update AdminResearch.js to show specific errors
    - [x] Update AdminContact.js to show specific errors
    - [x] Update AdminSubscribers.js to show specific errors
    - [x] Update Contact.js newsletter form to show specific errors
    - [x] Standardize error display in Admin pages

- [x] Home Page UX & Auth Restore
    - [x] Remove protect middleware from /api/stats
    - [x] Restore dark glassmorphism in App.css
    - [x] Fix text contrast on dark background
    - [x] Verify card gradients visibility

- [x] Website Footer Implementation
    - [x] Create Footer component and styles
    - [x] Integrate Footer into App.js
    - [x] Verify responsive design and styling

- [x] Admin UI Polishing
    - [x] Resize login box for better fit
    - [x] Fix navbar overlap on login page
    - [x] Reduce background particle opacity and fix layering (z-index)

- [x] Dynamic Admin Navigation
    - [x] Add auth detection to Navigation.js
    - [x] Implement conditional "Dashboard" and "Logout" links
    - [x] Add logout functionality to Navbar
    - [x] Verify navigation state updates on login/logout

- [x] Fix Project Form & Schema De-sync
    - [x] Update Project.js Model with missing fields (tech, link, github)
    - [x] Update AdminProjects.js Form with required fields (status, metricLabel, metricValue)
    - [x] Update AdminProjects.js Form with icon selection
    - [x] Verify project creation works without validation errors

- [x] UI Refinement: Uniform Cards
    - [x] Standardize Project card heights and flex behavior
    - [x] Ensure Research card grid consistency
    - [x] Verify responsive card scaling

- [x] Multi-Page Pagination
    - [x] Backend: Paginated controllers for Projects/Research
    - [x] Backend: Paginated controllers for Contacts/Subscribers
    - [x] Frontend: Reusable Pagination component
    - [x] Frontend: Integrate pagination in Public site
    - [x] Frontend: Integrate pagination in Admin portal
    - [x] Verify page switching across all views

- [x] Research Overhaul & Detail Modals
    - [x] Backend: Enhance Research.js model (add detailed fields)
    - [x] Backend: Update researchController for granular updates
    - [x] Frontend: Create reusable DetailModal component
    - [x] Frontend: Overhaul AdminResearch.js with separate section management
    - [x] Frontend: Integrate DetailModal in Projects.js
    - [x] Frontend: Integrate DetailModal in Research.js
    - [x] Verify modal responsiveness and details display
