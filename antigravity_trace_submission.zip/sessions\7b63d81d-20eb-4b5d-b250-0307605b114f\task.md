# Cloudinary Integration Tasks

- [ ] Install backend dependencies (`cloudinary`, `multer`, `multer-storage-cloudinary`)
- [ ] Create `backend/src/config/cloudinary.js`
- [ ] Create `backend/src/routes/upload.js` and mount in `index.js`
- [ ] Add `uploadImage` API call to `frontend/src/api/services.ts`
- [ ] Add File Upload button to Project, Certificate, and Experience modal forms in `AdminDashboard.tsx`
- [ ] Test the upload flow (pending user adding `.env` variables)
