# Build NEXUS — Autonomous Content-to-Action Agent

Building NEXUS per the provided Hackathon Challenge 1 specification. The system ingests 5 source types, scores credibility, detects contradictions, runs 5 parallel agents, validates actions, and simulates execution with failure recovery.

## User Review Required

The prompt provides a highly detailed specification. Please approve this plan to confirm that I should proceed with creating all the files in `e:\MERN\PROJECTS\aiseekho\nexus`.

## Proposed Changes

### Backend & Web Frontend
I will create the following files under `e:\MERN\PROJECTS\aiseekho\nexus\`:
#### [NEW] `PLAN.md`
#### [NEW] `README.md`
#### [NEW] `requirements.txt`
#### [NEW] `ingestion.py`
#### [NEW] `contradiction.py`
#### [NEW] `constraints.py`
#### [NEW] `agents.py`
#### [NEW] `simulator.py`
#### [NEW] `main.py`
#### [NEW] `index.html`

### Mobile App (Flutter)
I will create the Flutter app under `e:\MERN\PROJECTS\aiseekho\nexus\nexus_mobile\`:
#### [NEW] `pubspec.yaml`
#### [NEW] `lib/main.dart`
#### [NEW] `lib/config.dart`
#### [NEW] `lib/models/source_analysis.dart`
#### [NEW] `lib/models/agent_result.dart`
#### [NEW] `lib/models/consensus.dart`
#### [NEW] `lib/models/action_chain.dart`
#### [NEW] `lib/models/execution_result.dart`
#### [NEW] `lib/services/api_service.dart`
#### [NEW] `lib/screens/input_screen.dart`
#### [NEW] `lib/screens/debate_screen.dart`
#### [NEW] `lib/screens/execution_screen.dart`
#### [NEW] `lib/screens/chain_screen.dart`

## Verification Plan

### Automated Tests
1. Install Python dependencies: `pip install -r requirements.txt`
2. Start the FastAPI server: `uvicorn main:app --host 0.0.0.0 --port 8000`
3. Verify the endpoints are functional and the web UI (`index.html`) correctly interacts with the backend.
4. Set up the Flutter project: `cd nexus_mobile && flutter pub get`
5. Build the APK: `flutter build apk --release`

### Manual Verification
Review the UI and functionality by running through the requested scenarios (e.g., Supply Chain seed) in both the web interface and the mobile app to ensure they handle the four robustness scenarios correctly.
