# Task: Implement Rescheduling Logic

- [ ] Research existing rescheduling flow
- [ ] Design state machine changes
- [x] Implement Backend Logic
    - [x] `requestRescheduleByDoctor`
    - [x] `rescheduleByPatient` (with 24h check)
    - [x] Full refund logic on cancel (if doctor rescheduled)
- [/] Implement Frontend Logic
    - [x] Doctor UI: Request reschedule (reason only)
    - [x] Patient UI: Handle doctor request (pick time)
    - [x] Patient UI: Initiate reschedule (check 24h)
- [x] Verify

