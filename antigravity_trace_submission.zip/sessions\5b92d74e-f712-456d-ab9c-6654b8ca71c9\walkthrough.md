# Appointment Rescheduling Implementation

I have implemented a complete rescheduling flow that empowers both doctors and patients while ensuring fair refund policies.

## Key Features

### 1. Doctor-Initiated Rescheduling
- Doctors can now **request a reschedule** instead of forcing a new time.
- They allow the patient to choose a new time that works for them.
- **Status Change**: Appointment moves to `RESCHEDULE_REQUESTED`.
- **UI**: Doctor clicks "Reschedule", enters a reason, and sends the request.

### 2. Patient Rescheduling Flow
- **Responding to Requests**: Patients see "Action Required" / "Requests" for appointments where the doctor requested a change.
- **Booking New Time**: Patients can pick a new date and time for these requests without any additional payment.
- **Self-Service**: Patients can reschedule their own `CONFIRMED` appointments if it is more than **24 hours** before the slot.

### 3. Fair Refund Policy
- If a patient cancels an appointment that was **rescheduled by the doctor** (status `RESCHEDULE_REQUESTED`), they receive a **100% refund**.
- Standard cancellation rules apply for other scenarios (e.g., < 48 hours notice).

## Changes Summary

### Backend
- **Data Model**: Added `RESCHEDULE_REQUESTED` to Appointment status.
- **API**:
    - `POST /doctor/appointments/:id/request-reschedule`
    - `POST /patient/appointments/:id/reschedule`
- **Logic**: Updated `appointmentService.js` to handle status transitions and refund logic.

### Frontend
- **Doctor UI**: Updated Reschedule Modal to only ask for a reason.
- **Patient UI**:
    - Added **"Requests" tab** for easy visibility.
    - Added **Reschedule Modal** with date/slot selection.
    - Updated cancellation logic to show special refund message for doctor requests.

## How to Test

1.  **Doctor Request**:
    - Log in as Doctor.
    - Go to Dashboard/Appointments.
    - Click "Reschedule" on a Confirmed appointment.
    - Enter reason (e.g., "Emergency").
    - Verify status changes to `RESCHEDULE_REQUESTED`.

2.  **Patient Accept**:
    - Log in as Patient.
    - Go to Appointments -> "Requests" tab.
    - Click "Accept & Pick Time".
    - Select a new date/time.
    - Confirm. Status should change to `REQUESTED` (awaiting doctor final confirmation) or `CONFIRMED` (depending on immediate availability logic).

3.  **Patient Cancel (Refund)**:
    - Have a doctor request reschedule.
    - Log in as Patient -> Requests.
    - Click "Cancel Appointment".
    - Verify toast message says "Full refund processed".
