# Appointment System Refinements

Refine the doctor decline flow, enhance admin stats, and overhaul the patient appointment UI for consistency.

## Proposed Changes

### [Component] Doctor Appointments
- **[MODIFY] [page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/doctor/appointments/page.tsx)**:
  - Remove `confirm()` from `handleCancelAppointment`.
  - Add `showDeclineModal` and `declineReason` states.
  - Implement a glassmorphism modal for declining requests with a reason field.
  - Update `handleCancelAppointment` to use the provided reason.

### [Component] Admin Dashboard
- **[MODIFY] [page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/admin/dashboard/page.tsx)**:
  - Add a new "Confirmed Appointments" stat card to the top grid.
  - Ensure the confirmed count is correctly derived from `dashboardData.appointmentStats`.

### [Component] Patient Appointments
- **[MODIFY] [page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/patient/appointments/page.tsx)**:
  - Apply the premium glassmorphism theme.
  - Integrate `Scene` and `FloatingIcons` 3D background.
  - Use `framer-motion` for entry animations and tab transitions.
  - Standardize cards, buttons, and badges to match the doctor portal aesthetic (Emerald/Teal gradients).

## Verification Plan

### Automated Tests
- Run `npm run lint` to ensure no syntax errors.

### Manual Verification
1. **Doctor Decline**: Request an appointment as a patient, then as a doctor, try to decline. Verify the modal appears and the reason is sent.
2. **Admin Stats**: Log in as admin and verify the "Confirmed Appointments" card shows the correct value.
3. **Patient UI**: Log in as a patient and navigate to appointments. Verify the 3D background and glassmorphism styling are applied.
