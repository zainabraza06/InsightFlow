# Plan: Research System Overhaul & Detail Modals

Enhance the research data structure, provide granular administrative controls, and add immersive detail modals for projects and research areas.

## Proposed Changes

### [Backend] Data Models & Controllers

#### [MODIFY] [Research.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/backend/src/models/Research.js)
- Enhance `areas` schema with `longDescription`, `tech`, `link`, and `github`.
- Enhance `publications` schema with `abstract`, `authors`, and `link`.

#### [MODIFY] [researchController.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/backend/src/controllers/researchController.js)
- Support granular updates for "Areas", "Publications", and "Collaborations" sections independently.

### [Frontend] Shared Components

#### [NEW] [DetailModal.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/DetailModal.js)
- Create a premium glassmorphism modal for displaying item details.
- Support for images, tech stack tags, links, and long-form descriptions.

#### [NEW] [DetailModal.css](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/DetailModal.css)
- Stylized modal with backdrop blur, entrance animations, and responsive layout.

### [Frontend] Administrative & Public Views

#### [MODIFY] [AdminResearch.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/AdminResearch.js)
- Implement separate "Add" and "Save" buttons for each section (Areas/Publications/Collaborations).
- Update forms to accommodate new fields.

#### [MODIFY] [Projects.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/Projects.js)
- Make cards clickable to open `DetailModal` with project info.

#### [MODIFY] [Research.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/Research.js)
- Make research cards clickable to open `DetailModal` with area info.

## Verification Plan

### Manual Verification
- **Admin**: Add a new research area and save only that section. Verify data persists.
- **Admin**: Add a publication and save. Verify data persists.
- **Public**: Click on a project/research card. Verify the modal opens with the correct metadata.
- **Public**: Close the modal (ESC or Close button) and verify the backdrop clears.
- **Responsive**: Check modal display on mobile devices.
