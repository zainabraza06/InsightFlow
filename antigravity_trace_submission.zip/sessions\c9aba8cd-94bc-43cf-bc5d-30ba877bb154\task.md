# Tasks

- [x] Fix missing `StripeProviderProps` type in `StripeProvider.tsx`
    - [x] Define `StripeProviderProps` interface
    - [x] Verify the fix
