# Refined Registration, Approval, and Dashboard Stats

This plan addresses several user-requested refinements: improving the doctor approval flow, adding "Change Password" functionality to all dashboards, and correcting dashboard statistics.

## Proposed Changes

### Backend Enhancements

#### [MODIFY] [adminService.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/services/adminService.js)
- **`getDashboardStats`**:
    - Filter `totalDoctors` to count only `APPROVED`.
    - `pendingApprovals` count is already correct (`PENDING`).
- **`approveDoctorApplication`**:
    - Hash the provided password using `hashPassword`.
    - Update the associated `User` record: set `password_hash`, `is_active: true`, and `is_verified: true`.
    - Update `Doctor` record: `application_status: 'APPROVED'`, `approved_at: new Date()`.
    - Send email with credentials.

---

### Frontend Enhancements

#### [MODIFY] [apiClient.ts](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/lib/apiClient.ts)
- Add `changePassword` method calling `/auth/change-password`.

#### [MODIFY] [dashboard layout/components]
- Add a "Change Password" option to the user profile or sidebar in:
    - [Admin Dashboard](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/admin/dashboard/page.tsx)
    - [Doctor Dashboard](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/doctor/dashboard/page.tsx)
    - [Patient Dashboard](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/patient/dashboard/page.tsx)
- Create a reusable `ChangePasswordModal` component.

#### [MODIFY] [Admin Dashboard]
- **`User Distribution Chart`**: Remove 'Admin' from the data array before rendering.

---

## Verification Plan

### Manual Verification
1. **Doctor Registration**: Register as doctor -> check toast message.
2. **Doctor Approval**: Admin approves -> check if user can log in with generated password.
3. **Dashboard Stats**: Verify doctor count only includes approved ones and charts exclude admins.
4. **Change Password**: Test changing password from each dashboard.
