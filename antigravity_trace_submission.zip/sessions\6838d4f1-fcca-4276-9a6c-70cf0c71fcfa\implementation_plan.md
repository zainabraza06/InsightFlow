# Gesture Logic Refinement Plan

The user has identified three issues:
1.  **Scroll Jitter/Reversal**: Resetting the hand position (moving it back up after swiping down) triggers an unintentional "reverse" swipe.
2.  **Unintentional Disabling**: Gestures disable automatically, likely due to a too-sensitive "Fist Hold" detection.
3.  **Navigation Logic**: Ensure swipe left/right correctly navigates the navbar sequence.

## Proposed Changes

### [MODIFY] [GestureControl.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/speedCoding/frontend/src/components/GestureControl.js)

1.  **Directional Debounce (Scroll Reversal Fix)**:
    *   Implement a directional lockout.
    *   If a swipe (e.g., "swipe_down") is detected, block the *opposite* swipe ("swipe_up") for a longer duration (e.g., 1000ms).
    *   All other gestures remain on the standard debounce.

2.  **Increase Fist Hold Duration (Auto-Disable Fix)**:
    *   Increase `FIST_HOLD_MS` from `900ms` to `2000ms` (2 seconds).
    *   This requires a deliberate, sustained action to disable gestures, preventing accidental triggering during rest or transition.

### [MODIFY] [App.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/speedCoding/frontend/src/App.js)

1.  **Verify Navigation Logic**:
    *   Review `swipe_left` and `swipe_right` handlers.
    *   Current logic `currentIndex < pages.length - 1` stops at the last page.
    *   Confirm the `pages` array matches the actual route paths.
    *   Ensure `swipe_right` moves to the *next* page and `swipe_left` to the *previous*.

## Logic Detail: Directional Lockout

```javascript
const OPPOSITE_GESTURES = {
  'swipe_up': 'swipe_down',
  'swipe_down': 'swipe_up',
  'swipe_left': 'swipe_right',
  'swipe_right': 'swipe_left'
};

// Inside onResults/onGesture detection
if (swipe) {
  const lastGesture = lastGestureRef.current.gesture;
  const timeSinceLast = Date.now() - lastGestureRef.current.time;
  
  // If attempting opposite gesture too soon, ignore it
  if (OPPOSITE_GESTURES[swipe] === lastGesture && timeSinceLast < 1000) {
    return;
  }
}
```

## Verification

- [ ] **Scroll Reset**: Swipe down, then immediately move hand up. "Swipe Up" should NOT trigger.
- [ ] **Disable**: Hold fist. Should take 2 seconds to disable.
- [ ] **Navigation**: Swipe Right should go Home -> Research -> Projects -> Contact. Swipe Left should reverse.

### [MODIFY] [GestureControl.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/speedCoding/frontend/src/components/GestureControl.js)

1.  **Stricter Velocity Threshold**:
    *   Lower `STATIC_GESTURE_MAX_SPEED` from `0.05` to `0.02`.
    *   This ensures static gestures only trigger when the hand is *very* still.

2.  **Movement Cooldown**:
    *   Add a `movementCooldownRef` timestamp.
    *   Whenever velocity exceeds the threshold, update the cooldown timestamp.
    *   Block static gestures if `Date.now() - movementCooldownRef.current < 500ms`.
    *   This prevents "Open Palm" from triggering immediately after a swipe stops, while the hand is still relaxing.

## Verification

- [ ] **Open Palm Suppression**: Swipe vigorously. "Open Palm" should NOT trigger during or immediately after the swipe.
- [ ] **Static Triggering**: Hold hand steady. "Open Palm" should still trigger (after a brief delay).
