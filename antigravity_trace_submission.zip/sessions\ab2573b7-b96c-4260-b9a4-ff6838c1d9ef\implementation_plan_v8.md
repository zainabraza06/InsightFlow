# Admin Data Export Features

Add professional data export capabilities for Admins, allowing them to download Doctor records and System Logs in multiple formats (PDF, CSV, JSON) with high-quality PDF formatting.

## Proposed Changes

### Backend

#### [MODIFY] [adminService.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/services/adminService.js)
- Add `getAllDoctorsForDownload` to retrieve all doctor records with populated user data for export.

#### [MODIFY] [adminController.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/controllers/adminController.js)
- Create `downloadDoctorsController` to handle CSV, JSON, and PDF formats.
- Refine `downloadLogsController` PDF generation:
    - Adjust column widths to prevent text clipping.
    - Improve table alignment and styling (Landscape orientation is already set, but needs better spacing).
    - Center the title and generated timestamp.

#### [MODIFY] [adminRoutes.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/routes/adminRoutes.js)
- Add `router.get('/doctors/download', downloadDoctorsController)` endpoint.

---

### Frontend

#### [MODIFY] [apiClient.ts](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/lib/apiClient.ts)
- Add `downloadDoctorData` method (returns Blob).

#### [MODIFY] [AdminDoctorsPage](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/admin/doctors/page.tsx)
- Add an "Export Data" dropdown or buttons to download Doctors in different formats.

#### [MODIFY] [AdminLogsPage](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/admin/logs/page.tsx)
- Update/Add export buttons to trigger the refined PDF/CSV/JSON downloads.

## Verification Plan

### Automated Tests
- N/A (Manual UI verification)

### Manual Verification
- Log in as Admin.
- Navigate to **Doctor Personnel** page.
- Click "Export" and verify PDF (Landscape, Centered Table), CSV, and JSON downloads.
- Navigate to **System Logs** page.
- Click "Export" and verify the refined PDF layout (no clipping, landscape).
