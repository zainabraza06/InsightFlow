# Enhancing Appointment Rescheduling and Payment Visibility

This plan addresses the requirements for improved rescheduling logic (specifically for paid appointments), consistent payment status visibility across Admin, Patient, and Doctor interfaces, and final verification of the Zoom meeting link flow.

## Proposed Changes

### [Backend] Appointment Logic Refinement

#### [MODIFY] [appointmentService.js](file:///c:/Users/User/Desktop/MERN\PROJECTS/Remote_HealthCare_Management_System/backend/src/services/appointmentService.js)
- Update `rescheduleAppointment` signature to include `reason`.
- Implement logic: If `payment_status` is `PAID`, set `status` to `REQUESTED` while keeping `payment_status` as `PAID`.
- Update email notification to include the doctor's reason for rescheduling.
- Ensure the email to the patient clearly states the appointment has been "Re-requested" on their behalf due to a schedule change.

#### [MODIFY] [appointmentController.js](file:///c:/Users/User/Desktop/MERN\PROJECTS/Remote_HealthCare_Management_System/backend/src/controllers/appointmentController.js)
- Update `rescheduleAppointmentController` to extract `reason` from the request body and pass it to the service.

---

### [Frontend] API Client and UI Updates

#### [MODIFY] [apiClient.ts](file:///c:/Users/User/Desktop/MERN\PROJECTS/Remote_HealthCare_Management_System/frontend/src/lib/apiClient.ts)
- Update `rescheduleAppointment` to accept and send the `reason` parameter.

#### [MODIFY] [Doctor Appointments Page](file:///c:/Users/User/Desktop/MERN\PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/doctor/appointments/page.tsx)
- **Reschedule Modal**: Add a textarea for "Reason for Rescheduling".
- **Appointment Cards**: Display the current `payment_status` (PENDING/PAID) to the doctor so they know which consultations are secured.
- **Confirmation Logic**: Double-check that `meetingLink` is correctly passed and handled in `handleConfirmAppointment`.

#### [MODIFY] [Admin Appointments Page](file:///c:/Users/User/Desktop/MERN\PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/admin/appointments/page.tsx)
- Update the UI to highlight "Confirmed - Payment Pending" state explicitly.
- Ensure the status column reflective of both `status` and `payment_status`.

#### [VERIFY] [Patient Appointments Page](file:///c:/Users/User/Desktop/MERN\PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/patient/appointments/page.tsx)
- Ensure the "Action Required: Secure with Payment" message and "Pay Now" button are functioning correctly based on the user's manual edits.

## Verification Plan

### Automated Tests
- N/A (Manual Verification Preferred for UI flows)

### Manual Verification
1. **Initial Confirmation**: Confirm an online appointment as a doctor, providing a meeting link. Verify backend receives link.
2. **Status Visibility**: 
   - Admin check: "Confirmed" + "Payment Pending" visibility.
   - Doctor check: "Confirmed" + "Payment Pending" visibility in Upcoming list.
3. **Reschedule Paid Appointment**:
   - Patient pays for an appointment.
   - Doctor reschedules the appointment, providing a reason.
   - Verify status becomes `REQUESTED` in Doctor's "Pending Requests" and Patient's list.
   - Verify `payment_status` remains `PAID`.
   - Verify patient receives the appropriate email with the reason.
