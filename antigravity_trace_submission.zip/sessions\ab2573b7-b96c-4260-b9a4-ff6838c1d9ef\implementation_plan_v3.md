# Admin Dashboard Refinements: Pending Doctor Applications

This plan details the changes to streamline the doctor application process from the Admin Dashboard.

## Proposed Changes

### [Component] Frontend: API Client

#### [MODIFY] [apiClient.ts](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/lib/apiClient.ts)
- Update `approveDoctor` to use `/admin/approve-doctor` and accept `{ doctorId, password, doctorEmail }`.
- Update `rejectDoctor` to use `/admin/reject-doctor` and accept `{ doctorId, reason, doctorEmail }`.

### [Component] Frontend: Admin Dashboard

#### [MODIFY] [dashboard/page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/admin/dashboard/page.tsx)
-   **Limit to 5**: Ensure `pendingDoctors` is displayed with a maximum of 5 items.
-   **"View All" Link**: Add a link to `/admin/pending-doctors` if there are more than 5 requests.
-   **Action Buttons**: Replace "Review" button with separate "Approve" (emerald) and "Reject" (red) buttons.
-   **Approval Logic**:
    -   Generate a random password.
    -   Call `apiClient.approveDoctor(doctorId, password, doctorEmail)`.
-   **Rejection Logic**:
    -   Show a modal/dialog to capture a rejection reason.
    -   Call `apiClient.rejectDoctor(doctorId, reason, doctorEmail)`.

### [Component] Frontend: Pending Doctors Page

#### [MODIFY] [pending-doctors/page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/admin/pending-doctors/page.tsx)
-   Ensure the table uses separate "Approve" and "Reject" buttons for a consistent experience.

---

## Verification Plan

### Manual Verification
1. **Dashboard Check**: Verify only 5 requests are shown and "View All" leads to the correct page.
2. **Direct Approve**: Click "Approve" on a request from the dashboard. Confirm the loading state and success toast.
3. **Direct Reject**: Click "Reject" on a request. Confirm the reason modal appears and the rejection works.
4. **Pending Doctors Page**: Verify the buttons are also updated here.
