# Fix CI Build Failure (Warnings as Errors)

The build is failing in CI because `CI=true` treats ESLint warnings as errors.

## Proposed Changes

### [frontend](file:///C:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend)

#### [MODIFY] [GestureControl.js](file:///C:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/GestureControl.js)
- Move `OPPOSITE_GESTURES` constant outside the component to avoid hook dependency churn.

#### [MODIFY] [VoiceAssistant.js](file:///C:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/VoiceAssistant.js)
- Add `isListening` to the `useEffect` dependency array (line 179) to resolve the missing dependency warning and ensure the recognition starts/stops correctly when the toggle is clicked.

#### [MODIFY] [Projects.js](file:///C:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/Projects.js)
- Ensure `fetchProjects` is defined before its usage in `useEffect` (double-check the previous fix).

## Verification Plan

### Automated Tests
- Run `set CI=true && npm run build` (for Windows) to simulate the CI environment and ensure all warnings are resolved.

### Manual Verification
- Verify that Gesture Control and Voice Assistant still function as expected.

## Verification Plan

### Automated Tests
- Run `npm run build` in the `frontend` directory. I will carefully check the exit code and the full output for any warnings or errors that might cause failure in different environments.

### Manual Verification
- Verify that the UI still functions correctly (fetching data, delete/edit modals).
