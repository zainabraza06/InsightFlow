# Doctor Dashboard Modernization

This plan details the implementation of a full-featured, modernized Doctor Dashboard.

## User Review Required

> [!NOTE]
> I will be creating new backend routes and controllers specifically for the Doctor role, as they were missing from the current implementation.

## Proposed Changes

### [Backend] Routes & Controllers

#### [NEW] [doctorController.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/controllers/doctorController.js)
-   Implement `getDoctorDashboardController` to aggregate stats, appointments, and alerts.

#### [NEW] [doctorRoutes.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/routes/doctorRoutes.js)
-   Define `GET /dashboard` endpoint.
-   Secure with `authenticate` and `authorize('DOCTOR')` middleware.

#### [MODIFY] [routes/index.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/routes/index.js)
-   Mount `doctorRoutes` at `/doctor`.

### [Backend] Services

#### [MODIFY] [doctorService.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/services/doctorService.js)
-   Implement `getDoctorDashboard(doctorId)`:
    -   Calculate `totalPatients` (unique patients in confirmed appointments).
    -   Calculate `appointmentsToday`.
    -   Calculate `emergencyAlertsCount` (unacknowledged alerts).
    -   Fetch `upcomingAppointments`.
    -   Fetch `pendingRequests`.

### [Frontend] UI/UX Enhancements

#### [MODIFY] [doctor/dashboard/page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/doctor/dashboard/page.tsx)
-   **3D Background**: Integrate `Scene` and `FloatingIcons`.
-   **Glassmorphism**: Apply `glass-panel` and `backdrop-blur` to sections.
-   **Charts**:
    -   `PieChartWrapper` for Appointment Status distribution.
    -   `BarChartWrapper` for Weekly Appointments.
-   **Change Password**: Ensure the existing modal works and button matches the Admin Dashboard style.
-   **Loading State**: Improve with a themed loader.

---

## Verification Plan

### Automated Tests
- Test the new `/api/doctor/dashboard` endpoint with a Doctor token.

### Manual Verification
1. **Login as Doctor**: Verify the dashboard loads successfully.
2. **3D Effects**: Check if floating icons are visible.
3. **Charts**: Verify appointment data is correctly visualized.
4. **Stats**: Confirm total patients and today's appointments counts are accurate.
5. **Actions**: Confirm/Decline an appointment and verify the list refreshes.
