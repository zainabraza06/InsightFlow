# Doctor Status Management Implementation Plan

This plan details the implementation of a system for managing doctor account status (Active/Inactive), allowing doctors to request changes with reasons, and admins to manage these requests or manually toggle status with mandatory email notifications.

## User Review Required
> [!IMPORTANT]
> This feature requires modifying the `Doctor` schema and adding new email notification triggers.

## Proposed Changes

### Backend

#### [MODIFY] [backend/src/models/Doctor.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/models/Doctor.js)
-   Add `activation_request` field to store request details (`type`, `reason`, `status`, `date`).

#### [MODIFY] [backend/src/controllers/doctorController.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/controllers/doctorController.js)
-   Add `requestStatusChange` controller method.
-   Add route `POST /status-request`.

#### [MODIFY] [backend/src/controllers/adminController.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/controllers/adminController.js)
-   Add `manageDoctorStatus` controller method (Activate/Deactivate).
-   Update `getPaginatedDoctors` to support filtering by request status.

#### [MODIFY] [backend/src/services/emailService.js] (If exists, else create mock)
-   Add templates for `ACCOUNT_ACTIVATED`, `ACCOUNT_DEACTIVATED`, `STATUS_CHANGE_REQUEST_RECEIVED`.

### Frontend

#### [MODIFY] [frontend/src/app/doctor/dashboard/page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/doctor/dashboard/page.tsx)
-   Add "Account Status" card/section.
-   Add "Request Deactivation" / "Request Activation" button.
-   Add Modal to input reason.

#### [MODIFY] [frontend/src/app/admin/doctors/page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/admin/doctors/page.tsx)
-   **Filters**: Add tabs for "All Doctors", "Activation Requests", "Deactivation Requests".
-   **Table**: Add columns for "Request Status" and "Status".
-   **Actions**:
    -   "Review Request" button (opens modal showing doctor's reason).
    -   "Activate/Deactivate" button (opens modal for admin's reason).
-   **Modal**: Shared modal for confirming action and sending reason via email.

## Verification Plan

### Automated Tests
-   Verify backend endpoints return correct status codes.

### Manual Verification
1.  **Doctor Flow**:
    -   Log in as Doctor.
    -   Request Deactivation with reason "Taking a sabbatical".
    -   Verify UI updates to "Deactivation Requested".
2.  **Admin Flow**:
    -   Log in as Admin.
    -   Navigate to Doctors page.
    -   Filter by "Deactivation Requests".
    -   See the request from step 1.
    -   Click "Review".
    -   Confirm Deactivation with reason "Approved sabbatical".
    -   Verify Doctor status becomes "Inactive".
3.  **Email Check**:
    -   Verify (via logs) that email was sent to Doctor with the admin's reason.
