# UI Theme Overhaul & Functional Improvements

## Aesthetic Enhancements
- [x] Premium Navbar redesign with role-aware states
- [x] High-end Landing Page with 3D-feel and live indicators
- [x] Dashboard redesign with role-specific gradient themes
- [x] Staggered animations across all core views

## Functional Improvements
- [x] Role-based login redirects (Hostelite/Manager/Staff)
- [x] Tabbed Profile interface (Personal Info vs Security)
- [x] Integrated Password Change functionality into Profile Security tab
- [x] Dashboard cleanup (removed cluttering password forms)

## Verification
- [x] Unused components removed (`ChangePasswordCard.tsx`)
- [x] Final build passed successfully (`npm run build`)

## Mess Off Request Logic
- [ ] Backend: Strict 2-day lead time and min 1-day duration validation
- [ ] Backend: 12-day monthly limit logic (with split-month support)
- [ ] Frontend: Dashboard stat for "Mess Off Availed"
- [ ] Frontend: Request form validation

## Billing & Challan System
- [ ] Backend: New Challan model and monthly generation logic
- [ ] Backend: Late payment penalty logic
- [ ] Frontend: Challan listing and details page
- [ ] Frontend: Stripe integration (demo)
