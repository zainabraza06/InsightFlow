# Implementation Plan: Patient Dashboard Overhaul & Backend Integration

This plan details the steps to modernize the Patient Dashboard with 3D elements, health charts, and full backend integration.

## Backend Changes - The Foundation

### 1. Data Models
#### [NEW] [Vitals.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/models/Vitals.js)
- Fields: `patient_id` (ref Patient), `heartRate`, `systolicBP`, `diastolicBP`, `oxygenLevel`, `temperature`, `recorded_at`.

### 2. Services & Controllers
#### [MODIFY] [patientService.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/services/patientService.js)
- Add `getPatientDashboardData(userId)`: Aggregates vitals, upcoming appointments, and active alerts.
- Add `getVitalsHistory(patientId, days)`: Fetches historical vitals for charting.

#### [NEW] [PatientDashboardController](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/controllers/patientController.js)
- Implement `getPatientDashboardController` and `getVitalsHistoryController`.

### 3. Routes
#### [NEW] [patientRoutes.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/routes/patientRoutes.js)
- Define standard GET/POST routes for the dashboard and vitals.
#### [MODIFY] [index.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/routes/index.js)
- Mount `patientRoutes` at `/api/patient`.

---

## Frontend Changes - The Premium Experience

### 4. Dashboard Implementation
#### [MODIFY] [PatientDashboard](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/patient/dashboard/page.tsx)
- **3D Integration**: Enhance the existing `Scene` with specific health-related floating assets or refined animations.
- **Health Charts**: 
    - Integrate `BarChartWrapper` and `AreaChartWrapper` (or Sparklines) for Heart Rate and Blood Pressure trends.
- **Glassmorphism**: Refine existing cards with better transparency, backdrop-blur, and border-white/40.
- **Framer Motion**: Add entrance animations for a "living" UI feel.

## Verification Plan

### Automated Tests
- Test backend API endpoints `/api/patient/dashboard` and `/api/patient/vitals/history` using a script.

### Manual Verification
- Verify that real vitals data (if seeded) appears in the dashboard charts.
- Confirm 3D background is smooth and responsive to mouse movement.
- Ensure "Change Password" (Security) and "Emergency Alert" actions are fully functional.
