# open-palm-cooldown

The goal is to prevent the `open_palm` gesture from rapidly opening and closing modals by adding a specific cooldown period after each successful "toggle" action.

## User Review Required

> [!NOTE]
> **Intentional Toggling:**
> - A **1.5 second mandatory delay** will be added specifically for the **Open Palm** gesture.
> - This means after you open or close a modal using your palm, you must wait 1.5 seconds before the same gesture will trigger another open/close action.
> - This gives the modal animations time to complete and allows you to withdraw your hand without accidental re-triggers.

## Proposed Changes

### [Component Name] [GestureWeb Frontend]

#### [MODIFY] [Projects.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/Projects.js) & [Research.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/Research.js)
- Maintain a local `lastOpenPalmHandledTime` ref.
- In the `open_palm` gesture case, check if `Date.now() - lastOpenPalmHandledTime.current > 1500`.
- Update `lastOpenPalmHandledTime.current` after successful toggle.

## Verification Plan

### Manual Verification
1. Navigate to Projects.
2. Enable Card Mode (☝️).
3. Focus on a card.
4. Show **Open Palm** (🖐️) and keep it there.
5. Verify:
    - The modal opens.
    - The modal **DOES NOT** immediately close while your hand is still up.
    - It should only close if you keep your hand there for more than 1.5 seconds (or show the palm again after that time).
6. Repeat for closing the modal.
