# AI Fashion Stylist App completely built with secure Authentication!

Your modern MERN stack application mapping Next.js on the frontend and Express.js on the backend is completely built, including robust User Authentication.

## What was built
- **MERN Authentication**: Super secure password hashing with `bcryptjs` and tracking with JSON Web Tokens (`jsonwebtoken`). 
- **Next.js Global Auth State**: The frontend utilizes standard React Context (`AuthContext.tsx`) to globally supply session credentials.
- **Dynamic Navbar**: Globally handles the rendering logic dynamically switching between `Welcome, [Name]` or the standard `[Login / Sign Up]` buttons.
- **Massive 8-Brand Scalable Scraper**: Your `backend/scripts/scrapers/scraper.js` natively iterates over **Junaid Jamshed, Limelight, Zeen, Ethnic, Stylo, ECS, NDURE, and Tesoro** using generic Shopify selectors. It aggregates across identical DOM structures directly through native `fetch` wrappers bypassing strict Cloudflare thresholds, and intelligently feeds the database.

## How to Test and Run the Application

You need **two** terminal windows for this strict MERN client-server separation:

### 1. Start the Backend API Server
Open a terminal and set up your Node/Express API logic:
```bash
cd C:\Users\User\Desktop\MERN\PROJECTS\Fashion\backend
npm run dev
```
*(Runs on `http://localhost:5000`)*

### 2. Start the Frontend Next.js Interface
Open a **second** terminal and start your React/Next client:
```bash
cd C:\Users\User\Desktop\MERN\PROJECTS\Fashion\frontend
npm run dev
```
*(Runs on `http://localhost:3000`)*

### 3. Verification Workflow
1. Head to `http://localhost:3000` in your web browser. 
2. Create an account via "Sign Up" or query the AI Stylist publicly to generate 100% genuine dynamic fashion combinations sourced exclusively from the live Pakistani market!
