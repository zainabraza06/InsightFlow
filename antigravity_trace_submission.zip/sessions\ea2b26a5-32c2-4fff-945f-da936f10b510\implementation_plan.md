# Goal Description
Build a premium full-stack Next.js/Express application for an AI fashion stylist and product recommendation engine tailored to the Pakistani market. Introduce a full JWT-based Authentication system allowing users to register, log in, and manage sessions securely.

## User Review Required
> [!IMPORTANT]
> The Authentication infrastructure will support standard JWT login/registration using your Express server and a React Context layer in Next.js.
> 
> **Decision Needed**: 
> Should the main AI Fashion Stylist feature remain public for anyone to use (while logged parameters simply display their name on top), or should we completely **block** unauthorized users from using the AI Stylist until they log in?

## Proposed Changes
All code will be created in the `C:/Users/User/Desktop/MERN/PROJECTS/Fashion` directory.

### Backend Components (Express)
- [MODIFY] `backend/package.json`: Add `jsonwebtoken` and `bcryptjs`.
- [NEW] `backend/models/User.js`: Schema storing `name`, `email`, and `password` hashes.
- [NEW] `backend/routes/auth.js`: Endpoints for `/api/auth/register` and `/api/auth/login`.
- [NEW] `backend/middleware/authMiddleware.js`: JWT verification layer.
- [MODIFY] `backend/server.js`: Mount the new `/api/auth` router.

### Frontend Components (Next.js)
- [NEW] `frontend/src/context/AuthContext.tsx`: React Context to store JWT state globally using localStorage.
- [NEW] `frontend/src/components/Navbar.tsx`: Top navigation bar handling auth status and Logout.
- [NEW] `frontend/src/app/login/page.tsx`: A visually stunning, glassmorphism login form.
- [NEW] `frontend/src/app/register/page.tsx`: Corresponding registration form.
- [MODIFY] `frontend/src/app/page.tsx`: Import the Navbar and wrap the application (or layout) with AuthProvider.

## Verification Plan
### Manual Verification
- Start both the frontend and backend servers.
- Navigate to `/register` and create an account. Verify MongoDB saves the user with a properly hashed password.
- Log in and verify a JWT is issued and stored in the Next.js client.
- Test the "Logout" functionality and ensure React Context state is cleared perfectly.
