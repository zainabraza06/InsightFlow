# Implement Appointment Rescheduling Logic

The goal is to implement a robust rescheduling flow where:
1.  **Doctor-Initiated**: Doctor requests rescheduling (without picking a time). Patient receives notification, picks a new time. Doctor validates/accepts. (Full refund if patient cancels at this stage).
2.  **Patient-Initiated**: Patient requests rescheduling. Must be done > 24 hours before appointment. Doctor validates/accepts.

## User Review Required

> [!IMPORTANT]
> This change modifies the `Appointment` status enum and existing rescheduling endpoints. Frontend components will be updated to match the new API contracts.

## Proposed Changes

### Backend

#### [MODIFY] [backend/src/models/Appointment.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/models/Appointment.js)

- Update `status` enum to include `RESCHEDULE_REQUESTED`.

#### [MODIFY] [backend/src/services/appointmentService.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/services/appointmentService.js)

- **Rename/Modify** `rescheduleAppointment` (Doctor side) to `requestRescheduleByDoctor`:
    - accepts `appointmentId`, `doctorId`, `reason`.
    - Sets status to `RESCHEDULE_REQUESTED`.
    - Updates `reschedule_reason`.
    - Sends email to patient.
- **Add** `rescheduleAppointmentByPatient`:
    - accepts `appointmentId`, `patientId`, `newDate`, `newTime`, `reason`.
    - Checks 24h constraint (if status is `CONFIRMED`).
        - *Exception*: If status is `RESCHEDULE_REQUESTED` (Doctor initiated), ignore 24h check.
    - Updates `appointment_date`, `slot_start_time`, `slot_end_time`.
    - Sets status to `REQUESTED`.
- **Modify** `cancelAppointmentByPatient`:
    - Add check: If status is `RESCHEDULE_REQUESTED`, refund amount = full `payment_amount`.

#### [MODIFY] [backend/src/controllers/appointmentController.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/controllers/appointmentController.js)

- Expose `requestRescheduleByDoctor` and `rescheduleAppointmentByPatient`.

#### [MODIFY] [backend/src/routes/doctorRoutes.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/routes/doctorRoutes.js)

- Replace `POST /appointments/:id/reschedule` with `POST /appointments/:id/request-reschedule`.

#### [MODIFY] [backend/src/routes/patientRoutes.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/backend/src/routes/patientRoutes.js)

- Add route `POST /appointments/:id/reschedule` (Protected: Patient).

### Frontend

#### [MODIFY] [frontend/src/types/index.ts](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/types/index.ts)

- Update `Appointment` interface `status` to include `RESCHEDULE_REQUESTED`.

#### [MODIFY] [frontend/src/lib/apiClient.ts](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/lib/apiClient.ts)

- Update `rescheduleAppointment` to use new endpoints.
- Add `requestReschedule` (Doctor).
- Add `rescheduleAppointmentPatient` (Patient).

#### [MODIFY] [frontend/src/app/doctor/appointments/page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/doctor/appointments/page.tsx)

- Update Reschedule Modal: Remove Date/Time inputs. Only ask for Reason.
- Call `requestReschedule`.

#### [MODIFY] [frontend/src/app/patient/appointments/page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/patient/appointments/page.tsx)

- Handle `RESCHEDULE_REQUESTED` status display (e.g., in "Action Required" or specific tab).
- Show "Reschedule" button for `RESCHEDULE_REQUESTED` (No 24h limit) and `CONFIRMED` (24h limit).
- Implement Reschedule Modal/Form for Patient to pick new date/time.
- Update Cancel logic to display full refund message if `RESCHEDULE_REQUESTED`.

## Verification Plan

### Automated Tests
- None.

### Manual Verification
1.  **Doctor Reschedule**:
    - Doctor clicks Reschedule on a CONFIRMED appointment.
    - Enters reason "Urgent surgery".
    - Status changes to `RESCHEDULE_REQUESTED`.
2.  **Patient Response**:
    - Patient sees "Reschedule Requested" status.
    - Clicks Reschedule.
    - Picks new date.
    - Status changes to `REQUESTED`.
3.  **Doctor Confirm**:
    - Doctor sees request in Dashboard/Appointments.
    - Confirms it. Status -> `CONFIRMED`.
4.  **Patient Init Reschedule**:
    - Patient clicks Reschedule on CONFIRMED appointment.
    - If < 24h, shows error.
    - If > 24h, allows picking date. Status -> `REQUESTED`.
5.  **Refund**:
    - Doctor initiates reschedule.
    - Patient cancels.
    - Verify Full Refund.
