# Goal
1. Update **Certificates** and **Projects** to support image uploads via Cloudinary.
2. Add a **Hackathons** section (with image upload).
3. Add a **Kaggle Competitions** section.
4. Fix the **View More/Less** animation issue so items aren't invisible when expanded.
5. Fix the **Experience** timeline so that it correctly alternates left and right, and sorts from oldest to latest.

## User Review Required
Please review the proposed schema for the new Hackathon and Kaggle sections. Let me know if these fields cover everything you want!

**Proposed Hackathon Fields:** `title`, `description`, `date`, `projectUrl`, `certificateUrl`, `imageUrl`, `order`.
**Proposed Kaggle Fields:** `title`, `description`, `competitionUrl`, `rank` (or position/medal), `date`, `imageUrl`, `order`.

## Proposed Changes

### 1. Cloudinary Image Uploads (Projects & Certificates)
#### [MODIFY] `backend/src/routes/projects.js` & `backend/src/routes/certificates.js`
- Integrate `parser.single('image')` middleware for POST and PUT routes to handle image uploads to Cloudinary.

#### [MODIFY] `backend/src/models/Certificate.js`
- Keep `imageUrl`, rename `linkedInUrl` to `credentialUrl` (or add it) to be more generic.

#### [MODIFY] `frontend/src/pages/AdminDashboard.tsx`
- Update the **Projects** and **Certificates** forms to include a file input for images. Send the data as `FormData` instead of JSON.

### 2. New Hackathons & Kaggle Sections
#### [NEW] `backend/src/models/Hackathon.js` & `backend/src/models/Kaggle.js`
- Create the schemas and models for both.

#### [NEW] Backend Controllers & Routes
- Create CRUD operations (with image upload) for both, and register their routes in `backend/src/index.js`.

#### [MODIFY] `frontend/src/api/services.ts`
- Add API functions for fetching and managing Hackathons and Kaggle data.

#### [NEW] `frontend/src/section/Hackathons.tsx` & `frontend/src/section/Kaggle.tsx`
- Create new UI sections to display this data, matching the glassmorphism design.

#### [MODIFY] `frontend/src/App.tsx` & `frontend/src/pages/AdminDashboard.tsx`
- Render the new sections on the main page.
- Add new tabs in the Admin panel to manage Hackathons and Kaggle competitions.

### 3. Bug Fixes
#### [MODIFY] Frontend Sections (Projects, Certificates, Experience, Skills, Testimonials)
- **View More/Less Bug**: Currently, when you click "View More", the newly added elements are invisible because the scroll reveal observer only runs on page load. I will fix this by passing `[visibleCount]` to the `useScrollRevealAll` hook so the animation observer re-runs when the count changes!

#### [MODIFY] `frontend/src/section/Experience.tsx`
- **Alternating Layout Bug**: Remove the `order-last` CSS hack which broke the alternating row layout. I will statically place the left block, center dot, and right block in the DOM so that cards perfectly alternate left and right.
- **Sorting**: Reverse the array rendering to sort items from oldest to latest, as requested.

## Verification Plan
1. Test "View More" on all sections to verify items appear smoothly.
2. Visually inspect the Experience timeline code to guarantee cards correctly alternate left/right.
3. Test Cloudinary file uploads in the Admin Panel for Projects, Certificates, Hackathons, and Kaggle.
