# Major Portfolio Updates Task List

## Frontend Bug Fixes
- `[x]` Fix View More/Less bug in Projects, Certificates, Experience, Skills, and Testimonials (by passing `visibleCount` to `useScrollRevealAll`).
- `[x]` Fix Experience Timeline layout (DOM order for left/right alignment).
- `[x]` Reverse Experience sorting to show oldest to latest.

## Backend Schema & Routes
- `[x]` Modify `Certificate` model to add `credentialUrl`.
- `[x]` Update `projects.js` and `certificates.js` routes to support `parser.single('image')`.
- `[x]` Create `Hackathon` model, controller, and routes (with image upload).
- `[x]` Create `Kaggle` model, controller, and routes (with image upload).
- `[x]` Register new routes in `backend/src/index.js`.

## Frontend Integration
- `[x]` Update `src/api/services.ts` with Hackathon and Kaggle API calls.
- `[x]` Update AdminDashboard to support image file uploads for Projects and Certificates.
- `[x]` Add Hackathon and Kaggle management tabs to AdminDashboard.
- `[x]` Create `Hackathons.tsx` UI section.
- `[x]` Create `Kaggle.tsx` UI section.
- `[x]` Integrate `Hackathons.tsx` and `Kaggle.tsx` into the main application layout (`App.tsx` / `main.tsx`).
