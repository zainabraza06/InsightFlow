# fix-rock-point-conflict

The goal is to prevent the `point` (☝️) gesture from being triggered when the user performs the `rock_on` (🤘) gesture.

## Proposed Changes

### [Component Name] [GestureWeb Frontend]

#### [MODIFY] [GestureControl.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/GestureControl.js)
- **Prioritize Multi-Finger Gestures**:
    - Move `rock_on` (🤘) and `peace` (✌️) detection blocks **ABOVE** the `point` (☝️) detection block.
    - This ensures that if a hand pose satisfies both (e.g., Rock On satisfies Point's loose criteria), the more specific gesture (Rock On) is returned first.
- **Tighten Point Logic**:
    - Explicitly require that the **pinky finger is bent** (`s.pinkyScore < bent`) for a `point` gesture to be valid. This distinguishes it clearly from Rock On.
- **Refine Thresholds**:
    - Set `threshold = 0.7` (extended) and `bent = 0.45` (folded). 
    - This creates a clear gap and avoids the overlap where a finger could be considered both extended and bent simultaneously.

## Verification Plan

### Manual Verification
1. Navigate to Projects or Research.
2. Enable Card Mode (☝️).
3. Perform **Rock On** (🤘).
    - Verify: Modal opens/closes (Action handled).
    - BUG CHECK: It should **NOT** toggle the Card Mode (Point action).
4. Perform **Point** (☝️) with only the index finger extended and all others (including pinky) tightly bent.
    - Verify: Card Mode toggles.
5. Perform **Peace** (✌️).
    - Verify: Navigation to Home.
