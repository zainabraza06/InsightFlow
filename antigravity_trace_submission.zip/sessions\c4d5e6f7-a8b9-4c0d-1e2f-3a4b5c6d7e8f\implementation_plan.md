# Implementation Plan: Parallel Debate Mechanism (May 18)

## 🎯 Goal
Implement the core reasoning engine: A 3-agent parallel debate to resolve contradictions in ingested data.

## 🧠 Reasoning Engine Architecture
- **Orion (Pro-Action Analyst)**: Looks for immediate opportunities and aggressive actions.
- **Raven (Risk Analyst)**: Focuses on compliance, constraints, and potential downsides.
- **Cipher (Data Integrity Analyst)**: Checks for logical fallacies and temporal contradictions.
- **Resolver**: Synthesizes the debate into a final, actionable recommendation.

## 📝 Tasks
- [x] Implement async orchestration (`asyncio.gather`) for Orion, Raven, and Cipher.
- [x] Design prompt templates for each persona.
- [x] Build the Resolver agent to analyze the debate outputs.
- [x] Integrate debate results into the `/api/analyze` response payload.
