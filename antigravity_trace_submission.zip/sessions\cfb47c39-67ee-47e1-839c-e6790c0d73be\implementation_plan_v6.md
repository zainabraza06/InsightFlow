# fix-admin-modal-overflow

The goal is to prevent Admin modals from being cut off by adding internal scrolling and a maximum height.

## Proposed Changes

### [Component Name] [GestureWeb Frontend]

#### [MODIFY] [AdminManagement.css](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/AdminManagement.css)
- **.modal-overlay**:
    - Add `overflow: hidden` to disable the overlay-level scroll.
- **.modal-content**:
    - Add `max-height: 90vh` to limit the modal height.
    - Add `overflow-y: auto` to enable internal scrolling for form fields.
    - (Optional) Add custom scrollbar styling to match the theme.

## Verification Plan

### Manual Verification
- Open an Admin modal with many fields (e.g., "Add Publication").
- Resize the browser window to be small (short height).
- Verify that the modal content becomes scrollable and is no longer cut off by the viewport.
