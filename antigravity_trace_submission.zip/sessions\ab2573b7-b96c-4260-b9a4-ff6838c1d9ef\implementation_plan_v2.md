# Fix Unexpected Redirect on Page Refresh

This plan addresses the issue where users are redirected (potentially to the wrong page) upon refreshing.

## User Review Required

> [!IMPORTANT]
> I've identified a race condition in `ProtectedLayout`. It was redirecting to `/login` before the initial authentication check (`checkAuth`) finished restoring the user session from localStorage.

## Proposed Changes

### [Component] Authentication Logic

#### [MODIFY] [types/index.ts](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/types/index.ts)
- Add `isCheckAuthLoading: boolean` to `AuthState` to track the initial session restoration separately from login loading.

#### [MODIFY] [authStore.ts](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/lib/authStore.ts)
- Initialize `isCheckAuthLoading` to `true`.
- Update `checkAuth` to set `isCheckAuthLoading` to `false` once the API call to `/auth/me` completes (success or failure).

#### [MODIFY] [ProtectedLayout.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/components/ProtectedLayout.tsx)
- Wait for `isCheckAuthLoading` to be `false` before deciding whether to redirect to login.
- Show a loader while `isCheckAuthLoading` is `true`.

#### [MODIFY] [login/page.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/Remote_HealthCare_Management_System/frontend/src/app/login/page.tsx)
- Add a `useEffect` to automatically redirect authenticated users to their respective dashboards if they land on the login page. This prevents "sticky" login page behavior after a session is restored.

---

## Verification Plan

### Manual Verification
1. **Refresh on Dashboard**: Log in as a Patient/Doctor, then refresh the browser. Verify you stay on the dashboard and see a brief loader instead of being flicked to `/login` or `/admin`.
2. **Visit Login while Authenticated**: Manually navigate to `/login` while logged in. Verify you are automatically redirected back to your correct dashboard.
