# admin-voice-assistant

Add a voice assistant to the admin panel to allow adding, deleting, and editing data through speech commands.

## User Review Required

> [!IMPORTANT]
> **Voice Command Structure:**
> - To add: "Add project named [Name]" or "Add research area [Title]"
> - To delete: "Delete project [Name]" or "Remove research area [Title]"
> - To edit: "Edit project [Name]"
> - Navigation: "Go to projects", "Go to research", "Go home"

> [!NOTE]
> The assistant will use the **Web Speech API** (`SpeechRecognition` and `SpeechSynthesis`). It requires HTTPS (works on localhost) and user permission to access the microphone.

## Proposed Changes

### [Admin Infrastructure]

#### [NEW] [VoiceAssistant.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/VoiceAssistant.js)
- Floating microphone component.
- Handles `SpeechRecognition` lifecycle.
- Parses transcripts into intents: `ADD`, `DELETE`, `EDIT`, `NAVIGATE`.
- Uses `SpeechSynthesis` to provide verbal confirmation.

#### [NEW] [VoiceAssistant.css](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/VoiceAssistant.css)
- Premium styling for the microphone button (glowing ring, pulse animation when listening).

#### [NEW] [VoiceContext.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/context/VoiceContext.js)
- Provides a way for admin pages to register specific handlers for voice intents.
- `registerHandler(intent, callback)`

---

### [Admin Pages Integration]

#### [MODIFY] [AdminProjects.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/AdminProjects.js)
- Register handlers for:
    - `VOICE_ADD_PROJECT`: Auto-fills name and focuses the form.
    - `VOICE_DELETE_PROJECT`: Searches for the project by name and triggers delete (with verification).
    - `VOICE_EDIT_PROJECT`: Finds the project and enters edit mode.

#### [MODIFY] [AdminResearch.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/AdminResearch.js)
- Similar handlers for research areas and publications.

#### [MODIFY] [AdminDashboard.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/AdminDashboard.js)
- Wrap core content in `VoiceProvider` (or add it globally for admin routes).
- Render `VoiceAssistant` component.

## Verification Plan

### Automated Tests
- N/A (Web Speech API is hard to mock in headless tests).

### Manual Verification
1. Log in as Admin.
2. Click the Microphone button.
3. Speak: "Go to projects".
    - Verify: Page navigates to `/admin/projects`.
4. Speak: "Add project named Voice AI".
    - Verify: Project name field is filled and form is scrolled into view.
5. Speak: "Delete project Voice AI".
    - Verify: Confirmation dialog appears.
