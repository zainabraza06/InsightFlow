# 🛸 NEXUS InsightFlow — Implementation & Architecture Walkthrough
## Google Antigravity Hackathon Challenge 1 — Core Submission Document

This walkthrough provides an exhaustive technical analysis of how **NEXUS InsightFlow** meets and exceeds all requirements of **Challenge 1: Autonomous Content-to-Action Agent (Insight → Action System)**. It details the system's design, agentic reasoning pipeline, tool execution, and how the **Google Antigravity** session directly shaped the production implementation.

---

## 🗺️ 1. Core Architecture & Requirements Mapping

InsightFlow is divided into three production-ready layers:
1. **FastAPI Backend (Python 3.14)**: Core AI orchestration, 5-agent parallel pipeline, and integration engines.
2. **Next.js 14 Frontend (Web)**: Premium Dark-themed Glassmorphism administrative command HUD and analysis wizard.
3. **Flutter Mobile App (iOS/Android)**: Built with Dart, featuring 100% functional parity with the web dashboard.

Below is the definitive matrix mapping the hackathon prompt's mandatory requirements to their technical implementations:

| Challenge 1 Requirement | NEXUS Implementation Module | Active Production Files |
| :--- | :--- | :--- |
| **1. Content Understanding** | `IngestionEngine` supporting PDF, Text, CSV, and URLs. Includes noise filtering. | [ingestion.py](file:///e:/MERN/PROJECTS/aiseekho/backend/ingestion.py) |
| **2. Insight Extraction** | `ContradictionEngine` temporal analysis + credibility attribution. | [contradiction.py](file:///e:/MERN/PROJECTS/aiseekho/backend/contradiction.py) |
| **3. Impact Analysis** | `ConsensusEngine` agent debate assessing worst-case cascades. | [agents.py](file:///e:/MERN/PROJECTS/aiseekho/backend/agents.py) |
| **4. Action Generation** | `ExecutorAgent` 5-step causal chain with dependency graphs. | [agents.py](file:///e:/MERN/PROJECTS/aiseekho/backend/agents.py) |
| **5. Action Simulation** | `ActionSimulator` executing real Gmail, Sheets, and Slack updates. | [simulator.py](file:///e:/MERN/PROJECTS/aiseekho/backend/simulator.py) |
| **6. Outcome Visualization** | Before/After stats, visual Disagreement Meters, and live logs. | [dashboard/page.tsx](file:///e:/MERN/PROJECTS/aiseekho/frontend-next/src/app/(protected)/dashboard/page.tsx) |
| **7. Agentic Workflow** | 5-Agent parallel debate via `asyncio.gather` with Resolver synthesis. | [main.py](file:///e:/MERN/PROJECTS/aiseekho/backend/main.py) |
| **8. Antigravity Trace** | Complete visual trace visualizer and session `.zip` bundle. | [README.md](file:///e:/MERN/PROJECTS/aiseekho/README.md) |

---

## ⚡ 2. The 7-Phase Agentic Execution Flow

Every source ingested by NEXUS flows through an autonomous, feedback-driven pipeline:

```mermaid
graph TD
    A[Unstructured Sources: PDF/CSV/URL/Text] -->|Ingest| B(IngestionEngine)
    B -->|Score Credibility & Noise| C(ContradictionEngine)
    C -->|Detect Cross-Source Conflicts| D(ConsensusEngine)
    D -->|asyncio.gather| E[Orion Analyst: Optimist]
    D -->|asyncio.gather| F[Raven Analyst: Pessimist]
    D -->|asyncio.gather| G[Cipher Analyst: Realist]
    E & F & G -->|Debate Insights| H(Resolver Agent: Synthesizer)
    H -->|Consensus Insight| I(Executor Agent: Planner)
    I -->|Drafts 5-Step Action Chain| J(ConstraintChecker)
    J -->|Validates Time/Budget/Staff| K(ActionSimulator)
    K -->|Halt Production / Alert Slack| L[Real Integrations: Gmail, Slack, Sheets]
    L -->|User Feedback 1-5| M(FeedbackStore)
    M -->|Domain Learning Context| D
```

### 📂 Phase 1 — Multi-Source Ingestion
The system processes unstructured data across 5 distinct channels:
*   **PDF Document Parsing**: Uses PyMuPDF to extract text paragraphs and check for formatting anomalies (Credibility base: `0.85`).
*   **CSV Structured Logs**: Uses `csv.DictReader` to automatically detect chronological timelines (Credibility base: `0.90`).
*   **HTTP Crawling**: Extracts clean text from external URLs while stripping HTML tags (Credibility base: `0.70`).
*   **Raw Prose Text**: A text area for copy-pasted operational updates (Credibility base: `0.65`).
*   **Mock Feed Streams**: Fast-path API testing channel (Credibility base: `0.60`).

### 📊 Phase 2 — Deterministic Credibility Scoring
To ensure decision-grade inputs, `ContradictionEngine` adjusts each source's credibility index:
*   **Temporal Columns (CSV)**: `+0.05` for presence of explicit date/time columns.
*   **Noisy Language Exclusions**: `-0.15` penalty for words like *allegedly, rumored, unconfirmed, breaking*.
*   **Stale Data Modifiers**: `-0.20` penalty for stale temporal references like *yesterday, last week, last month*.
*   **Rejection Gating**: Any source falling below a `0.30` credibility score is excluded, preventing hallucinations.

### 🕵️ Phase 3 — Contradiction & Temporal Trend Detection
The contradiction engine identifies overlapping statements about key metrics and resolves them based on trust rankings:
1.  **Recency Overrides**: If Source A (dated May 18) claims SKU-001 stock is 80, and Source B (dated March 1) claims it is 1200, the temporal parser flags a contradiction and defaults to the most recent data point.
2.  **Rate-of-Change Mapping**: The temporal analyzer maps these discrepancies onto a trendline (e.g., 1200 $\rightarrow$ 600 $\rightarrow$ 200 $\rightarrow$ 80) and identifies the trend direction as **Worsening**, with a projected date of depletion.

### 🎭 Phase 4 — 5-Agent Parallel Debate (`asyncio.gather`)
Rather than sequentially calling LLMs, NEXUS fires Orion, Raven, and Cipher in parallel:
```python
# From e:\MERN\PROJECTS\aiseekho\backend\main.py
async def run_parallel_debate(combined_text, domain, learning_context):
    results = await asyncio.gather(
        orion.analyze(combined_text, learning_context),
        raven.analyze(combined_text, learning_context),
        cipher.analyze(combined_text, learning_context)
    )
    return results
```
*   **Orion (Optimist Persona)**: Identifies hidden silver linings (e.g., local supplier options or regulatory loopholes).
*   **Raven (Pessimist Persona)**: Highlights cascade failure points, logistics deadlocks, and worst-case cash flow implications.
*   **Cipher (Realist Persona)**: Determines mathematical confidence intervals, likelihood percentages, and standard deviations.

*   **Resolver (The Synthesizer)**: Reconciles all three arguments, resolves Disagreement Meters, and outputs a single consensus insight.
*   **Executor (The Action Planner)**: Takes the Resolver's output and structures a rigorous **5-step causal action chain** where each action explicitly states its `triggered_by` and `enables` identifiers.

### ⚖️ Phase 5 — Deterministic Constraint Validation
Before execution, the action chain is passed to `ConstraintChecker`. This checker is written in pure Python, making zero external API calls to minimize latency and cost:
$$\text{Max Step Budget} = \frac{\text{Total Budget}}{5}$$
$$\text{Max Step Time} = \frac{\text{Max Hours} \times 60}{5} \times \text{Urgency Multiplier}$$
*Where urgency level multipliers are Low (1.5), Medium (1.0), High (0.7), and Critical (0.4).*
If an action violates these constraints, `was_modified` is set to `True`, and the budget or timeline is dynamically capped to keep the plan feasible.

### 🚀 Phase 6 — Causal Action Simulation
Once validated, the simulator executes the steps in order:
1.  **Step 1 — Diagnostic**: Deep local search (Simulated).
2.  **Step 2 — Notification (SMTP)**: Sends a formatted notification email using **Gmail SMTP** to the operations manager's address.
3.  **Step 3 — Ledger Log (Google Sheets)**: Interacts with the **Google Sheets API** using a service account to write a tracking row containing timestamp, domain, cost, and latency.
4.  **Step 4 — Slack Alert (Webhooks)**: Triggers an outgoing HTTP POST payload to a **Slack incoming webhook** notifying channels of status changes.
5.  **Step 5 — Monitoring**: Periodically logs metrics to track operational recovery.

### 🔄 Phase 7 — Dynamic Reinforcement Feedback Loop
When users submit feedback (rating 1-5) on an execution, it is stored in `feedback.json`. The engine computes the running average for each domain:
*   **Average Rating < 3.0**: Triggers warning directives: *"Users are highly dissatisfied. Ensure future insights cite concrete sources and name specific entities."*
*   **Average Rating >= 4.0**: Directs positive reinforcement: *"Users are highly satisfied. Maintain this style."*
*   This context is dynamically prepended to all subsequent agent prompts, creating a true closed-loop learning pipeline.

---

## 🛠️ 3. Google Antigravity & Orchestration Impact

NEXUS was developed in the **Antigravity AI IDE**, using its advanced workflow tools to ensure structural alignment with Challenge 1 guidelines:
*   **Zero Superficially**: Rather than calling Gemini for basic tasks, the system uses custom parsers like `raw_decode()` to extract JSON out of prose. This handles rate-limit fallbacks (`HTTP 429`) with backoffs and switches seamlessly from OpenRouter to direct Gemini calls.
*   **Tool Gating**: The `/admin` command center allows platform administrators to reset the reinforcement feedback database, wipe user execution histories, and monitor live costs.
*   **Visual Parity**: Features like the *Disagreement Meter* and *Risk Timeline* provide a clear breakdown of AI reasoning, letting you inspect agent behavior during development.

---

## 🌟 4. Technical Innovation & Edge-Case Handling

To prepare the application for production hosting, several structural safeguards were built in:
1.  **FastAPI Dependency Injection**: All administrative endpoints (`/admin/*`) are protected using token decode helpers to ensure robust access control.
2.  **JSON Prose Robustness**: LLMs often output markdown blocks (` ```json ... ````) or conversational preambles. NEXUS's parser extracts JSON using structured regex searches, preventing client-side rendering crashes.
3.  **Transaction Safety**: If an API call fails during Step 3 or 4 of execution, the system rolls back to safe defaults, logs the incident, and gracefully finishes the remaining steps.

---

## 🏗️ 5. Deployment Readiness Checklist

InsightFlow is ready for deployment:
*   **FastAPI Backend**: Fully seeded with default credentials `admin@nexus.ai` / `admin12345`.
*   **Next.js Frontend**: Successfully built (`npm run build`) with **Exit Code: 0** and zero TypeScript errors.
*   **Flutter Mobile**: Compiles with fully synchronized API routes.
*   **Session Trace**: The complete development workspace history is preserved in `antigravity_trace_submission.zip` for final evaluation.
