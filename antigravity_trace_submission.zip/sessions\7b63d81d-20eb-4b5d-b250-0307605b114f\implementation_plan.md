# Add Cloudinary Image Uploads

Integrate Cloudinary into the MERN stack portfolio to allow direct image uploads from the Admin Dashboard for Projects, Certificates, and Experience entries.

## ⚠️ User Review Required

I will need to install the following backend dependencies: `cloudinary`, `multer`, and `multer-storage-cloudinary`. 
**Crucially, you will need to provide your Cloudinary API credentials in the `backend/.env` file for this to work.**

## ❓ Open Questions

1. Do you already have a free [Cloudinary](https://cloudinary.com/) account created, and are your API Key, API Secret, and Cloud Name ready to paste into your `.env` file?
2. Do you want the uploaded images to replace the manual "Image URL" text box completely, or should I leave the text box there so you can choose to either upload a file OR paste a URL?

## Proposed Changes

### Backend

#### [NEW] `backend/src/config/cloudinary.js`
- Configure the `cloudinary` v2 SDK using environment variables.
- Setup `multer-storage-cloudinary` to automatically parse uploaded files and stream them directly to your Cloudinary storage folder.

#### [NEW] `backend/src/routes/upload.js`
- Expose a `POST /api/upload` endpoint protected by the `verifyToken` middleware.
- Return the secure Cloudinary image URL upon successful upload.

#### [MODIFY] `backend/src/index.js`
- Mount the new `/api/upload` route.

#### [MODIFY] `backend/package.json`
- Install `cloudinary`, `multer`, and `multer-storage-cloudinary`.

### Frontend

#### [MODIFY] `frontend/src/api/services.ts`
- Add an `uploadImage(file: File)` service function that sends a `multipart/form-data` request to the backend.

#### [MODIFY] `frontend/src/pages/AdminDashboard.tsx`
- In the Generic Modal for Projects, Certificates, and Experience, add a "Choose File" / "Upload" button next to or below the Image URL field.
- Add local state to handle the uploading loading indicator while the image is being sent to Cloudinary.
- Automatically populate the `imageUrl` form field with the returned Cloudinary URL once the upload completes.

## Verification Plan

1. Install dependencies and start the backend.
2. Ask the user to insert `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, and `CLOUDINARY_API_SECRET` into `backend/.env`.
3. Test uploading a small image from the Admin Dashboard to a Project.
4. Verify the frontend form updates with the generated Cloudinary URL and saves correctly.
