# Occupancy & Billing Monitoring System

Implement occupancy rate visibility for managers and a comprehensive billing/challan monitoring system for Admin and Managers.

## Proposed Changes

### Backend

#### [MODIFY] [billingController.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/backend/controllers/billingController.js)
- Implement `getAllChallansGlobal` for Admin monitoring (pagination, filtering by hostel, status, month).
- Implement `getHostelChallans` for Manager monitoring (pagination, filtering by status, month).

#### [MODIFY] [billingRoutes.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/backend/routes/billingRoutes.js)
- Add `GET /all` (Admin only).
- Add `GET /hostel` (Manager only).

### Frontend

#### [MODIFY] [DashboardStats interface](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/manager/dashboard/page.tsx)
- Update `DashboardStats` to include `occupiedRooms`, `totalRooms`, and `occupancyRate`.

#### [MODIFY] [ManagerDashboardPage](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/manager/dashboard/page.tsx)
- Display a new `StatCard` for Occupancy Rate.

#### [NEW] [AdminBillingPage](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/admin/billing/page.tsx)
- Global monitoring of all challans.

#### [NEW] [ManagerBillingPage](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/manager/billing/page.tsx)
- Monitoring of challans for students in the manager's hostel.

#### [MODIFY] [api.ts](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/services/api.ts)
- Add `billingService` with:
    - `getGlobalChallans`
    - `getHostelChallans`

#### [MODIFY] [Navbar.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/components/Navbar.tsx)
- Add "Billing" link to Admin and Manager nav links.

## Verification Plan

### Automated Tests
- Test new billing endpoints using manual calls or scripts.

### Manual Verification
- Login as Manager: Verify Occupancy Rate is visible on dashboard.
- Login as Manager: Navigate to Billing and verify only hostel-specific students' bills are shown.
- Login as Admin: Navigate to Billing and verify all students' bills are shown.
