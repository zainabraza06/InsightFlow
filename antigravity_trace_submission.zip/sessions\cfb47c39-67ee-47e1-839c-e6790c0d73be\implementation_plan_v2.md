# enhance-modal-fields

The goal is to ensure `DetailModal` displays all available information from the backend models, including a new layout for publications and improved display for research areas and projects.

## Proposed Changes

### [Component Name] [GestureWeb Frontend]

#### [MODIFY] [DetailModal.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/DetailModal.js)
- Update the header to handle different types more gracefully (e.g., using `data.authors` as a subtitle for publications).
- Add support for `type === 'publication'`.
- Display new sections for:
    - **Authors & Venue**: Specifically for publications.
    - **Abstract**: For publications (can also be used for research areas if they have it).
    - **Tech Stack**: Ensure it shows for all types if present.
- Ensure `longDescription` is prioritized but potentially show `description` as a brief intro if both exist.

#### [MODIFY] [DetailModal.css](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/DetailModal.css)
- Add styles for the new sections (`authors-info`, `abstract-section`, etc.).
- Refine typography for better readability of long abstracts or descriptions.

#### [MODIFY] [Research.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/Research.js)
- Make publication items clickable.
- Update `handleCardClick` (or add `handlePublicationClick`) to set the `selectedArea` and `type="publication"`.

## Verification Plan

### Manual Verification
- Open Research page and click a Publication. Verify it shows authors, venue, year, abstract, and link.
- Open Research page and click a Research Area. Verify it shows all fields (title, description, long description, tech, links).
- Open Projects page and click a Project. Verify it shows all fields (metrics, tech, links).
- Verify that if a field is missing in the data, the corresponding section is hidden (not empty).
