# Task: Implement Monthly Challan for Hostelite

## Status
[/] Planning
[ ] Implementation
    [x] Backend: Enhance billing controller (1000 penalty for unpaid months)
    [x] Frontend: Create `billingService.ts`
    [x] Frontend: Create `ChallanCard` component
    [x] Frontend: Create `ChallanList` component (Sorted by date ascending)
    [x] Frontend: Integrate `ChallanList` into Hostelite Dashboard
    [x] Frontend: Implement Stripe Payment flow (Mock)
[x] Stripe Environment & Testing Infrastructure
    [x] Backend: Update `.env.example` with Stripe keys
    [x] Backend: Create `tests/messOff.test.js` (Verify 1st day skip & splitting)
    [x] Backend: Create `tests/billing.test.js` (Verify dynamic fee & > 1 day threshold)
    [x] Backend: Update `package.json` with test scripts
[x] Verification
    [x] Run all test scripts and verify output
