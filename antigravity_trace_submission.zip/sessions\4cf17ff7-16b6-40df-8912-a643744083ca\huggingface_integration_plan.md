# Hugging Face Integration Plan

This plan outlines how to integrate Hugging Face into the AuraFit platform. We will focus on implementing an **Image Tagging Service** using the Hugging Face Inference API. This will allow the platform to automatically detect fashion attributes (like clothing type, fabric, or style) from product images, supplementing our existing scrapers.

## 1. Setup & Environment
- Install the `@huggingface/inference` library.
- Add `HUGGING_FACE_API_KEY` to the `.env` file.
- Obtain a free API token from [huggingface.co/settings/tokens](https://huggingface.co/settings/tokens).

## 2. Implementation Steps

### Step 2.1: Infrastructure
Create a dedicated service file `backend/services/huggingface.js` to manage API calls. We will use the `HUGGING_FACE_API_KEY` to authenticate.

### Step 2.2: Image Classification (Auto-Tagging)
Integrate a model like `microsoft/resnet-50` or a more fashion-specific one like `valentina-fons/fashion-classification` to analyze product images.
- **Input**: Image URL (from scraped products).
- **Output**: Array of tags with confidence scores.

### Step 2.3: CLIP Visual Search (Advanced)
Integrate `openai/clip-vit-base-patch32` to generate multimodal embeddings. This allows users to search for "Floral pink dress" and get results based on visual features rather than just keywords.

## 3. Proposed Service Structure (`huggingface.js`)

```javascript
import { HfInference } from '@huggingface/inference';
import dotenv from 'dotenv';
dotenv.config();

const hf = new HfInference(process.env.HUGGING_FACE_API_KEY);

export const classifyFashionImage = async (imageUrl) => {
  // Logic to call image-classification
};

export const generateVisualEmbedding = async (imageUrl) => {
  // Logic to call feature-extraction (CLIP)
};
```

## 4. Integration Points
- **Scraper Pipeline**: Call `classifyFashionImage` during the scraping process to fill in missing `style` or `subCategory` fields.
- **Search API**: Implement a new `/api/search/visual` endpoint that accepts an image upload and uses CLIP embeddings for similarity search.

---

**Next Steps:**
1. Install dependencies: `npm install @huggingface/inference` in the backend.
2. Update `.env` with your API key.
3. Create the `huggingface.js` service.
