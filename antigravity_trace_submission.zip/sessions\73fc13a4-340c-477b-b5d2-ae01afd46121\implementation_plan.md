# Mess Request & Automated Billing System

Implement strict constraints for mess off requests and an automated monthly billing (Challan) system with Stripe integration.

## Proposed Changes

### Backend

#### [NEW] [Challan.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/backend/models/Challan.js)
Define the schema for monthly bills:
- `hostelite`: reference to Hostelite
- `month`: (e.g., "February 2026")
- `baseMessFee`: Fee from Hostel model
- `messOffDiscount`: Calculated as `approvedDays * 580`
- `penalty`: Late fee if applicable
- `totalAmount`: Final payable amount
- `status`: ['UNPAID', 'PAID', 'OVERDUE']
- `stripePaymentId`: For tracking transactions

#### [MODIFY] [MessOffRequest.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/backend/models/MessOffRequest.js)
- Add `approvedDaysPerMonth`: Object to store day counts (e.g., `{ "2026-02": 5, "2026-03": 2 }`) to handle requests spanning two months.

#### [MODIFY] [requestController.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/backend/controllers/requestController.js)
Update `submitMessOffRequest`:
- Validate `startDate` is ≥ 2 days in the future.
- Validate `endDate - startDate` > 1 day.
- Calculation Logic:
  - If request spans two months, split into Month A and Month B.
  - Fetch existing approved mess-off days for the user in both months.
  - Apply 12-day cap per month. Skip/Truncate overflow days.
  - Automatically set status to `APPROVED` for valid requests (or keep pending for manager review, but calculate potential discount).

#### [NEW] [billingController.js] & [billingRoutes.js]
- Logic to generate Challans on the last day of the month.
- logic to apply penalties for late payments from previous months.
- Stripe payment intent creation.

### Frontend

#### [MODIFY] [NewRequestPage.tsx](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/hostelite/requests/new/page.tsx)
- Add client-side validation logic for Mess-Off requests (2-day lead time, min duration).
- Show warnings if the user is approaching their 12-day monthly limit.

#### [MODIFY] [Hostelite Dashboard](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/hostelite/dashboard/page.tsx)
- Add "Mess Off Availed" stat card with a progress bar (e.g., "7 / 12 days this month").

#### [NEW] [Challan Listing Page](file:///c:/Users/User/Desktop/MERN/PROJECTS/NHMS/Nust_Hostel_Management_System/frontend/src/app/(dashboard)/hostelite/challans/page.tsx)
- View monthly challans, status, and Payment button.

## Verification Plan

### Automated Logic Testing
- Submit mess off requests with various dates (spanning months, exceeding 12 days, insufficient lead time) and verify backend rejection/capping.
- Trigger challan generation manually via a hidden route or script and verify correct PKRs calculation.

### Manual UI Testing
- Verify "Mess Off Availed" card updates correctly on the dashboard.
- Test Stripe checkout flow (mock success/failure).
