# swipe-cooldown-refinement

The goal is to prevent accidental "back and forth" (ping-pong) navigation triggers when a user moves their hand back to the center after a swipe.

## User Review Required

> [!NOTE]
> **Swipe Timing:**
> - The **Wait Time** between horizontal swipes (Next/Prev) will be increased to **1.2 seconds**.
> - The **Opposite Lockout** (e.g., swiping Right immediately followed by Left) will be increased to **1.5 seconds**.
> - This ensures that the "return to center" motion of your hand is ignored by the system.

## Proposed Changes

### [Component Name] [GestureWeb Frontend]

#### [MODIFY] [GestureControl.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/GestureControl.js)
- **Increase Cooldowns**:
    - Update opposite gesture lockout: `timeSinceLast < 1000` -> `timeSinceLast < 1500`.
    - Update global horizontal cooldown: `timeSinceLast < 800` -> `timeSinceLast < 1200`.
- **Tighten Horizontal Detection**:
    - Update `detectSwipe` horizontal axis tolerance: `absDx > absDy * 1.2` -> `absDx > absDy * 1.8`.
    - Increase `linearity` requirement for horizontal swipes to `0.7` to ensure only fast, straight motions trigger navigation.

## Verification Plan

### Manual Verification
1. Navigate to Projects.
2. Perform a fast swipe **Right** (👈 Previous Page).
3. Immediately move your hand back to the center of the camera.
4. Verify:
    - The page navigates once.
    - It **DOES NOT** navigate back to the previous page during the return motion.
5. Wait ~1.5 seconds and swipe again.
    - Verify: Navigation works correctly when done deliberately.
