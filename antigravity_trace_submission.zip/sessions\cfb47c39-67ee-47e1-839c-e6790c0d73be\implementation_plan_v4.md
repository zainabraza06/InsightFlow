# fix-admin-ui-and-css-isolation

The goal is to resolve UI breakage on the Admin Research page caused by CSS class collisions and fix layout issues with buttons.

## User Review Required

> [!IMPORTANT]
> I am renaming the generic `.modal-overlay` and `.modal-content` classes in `DetailModal` to `detail-modal-overlay` and `detail-modal-content`. This prevents the "professional" modal styles from leaking into other modals (like the ones in the admin panel) that might have different layout requirements.

## Proposed Changes

### [Component Name] [GestureWeb Frontend]

#### [MODIFY] [DetailModal.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/DetailModal.js)
- Update class names from `modal-overlay` to `detail-modal-overlay` and `modal-content` to `detail-modal-content`.

#### [MODIFY] [DetailModal.css](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/DetailModal.css)
- Rename `.modal-overlay` -> `.detail-modal-overlay`.
- Rename `.modal-content` -> `.detail-modal-content`.

#### [MODIFY] [AdminManagement.css](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/AdminManagement.css)
- Update `.save-btn`: Remove `flex: 1` to prevent it from stretching to full width in general flex containers.
- Move `flex: 1` to a more specific selector, like `.form-actions .save-btn`, where stretching is desired.
- Add `width: fit-content` and `min-width: 15rem` (or similar) to ensure "Add" buttons look professional but not oversized.

#### [MODIFY] [AdminResearch.js](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/pages/AdminResearch.js)
- Ensure it uses explicit styles or its own scoped classes if the "missing CSS" persists.
- (Optional) Refactor the internal modal to use the `AdminManagement` specific modal styles if they exist.

## Verification Plan

### Manual Verification
- **Admin Panel**: Check the Research management page. Verify "Add" buttons are normally sized.
- **Admin Panel**: Open the "Add Area" or "Edit Area" modals. Verify they are centered and readable (since they will now use their own `AdminManagement.css` styles without collision).
- **Public Site**: Open Project/Research modals. Verify they still use the "professional" portal + scroll styling and haven't lost their look.
