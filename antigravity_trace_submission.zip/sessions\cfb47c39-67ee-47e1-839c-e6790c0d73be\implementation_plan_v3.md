# modal-internal-scrolling

The goal is to update the `DetailModal` so that the content box itself scrolls internally, while the modal remains fixed and centered in the viewport.

## Proposed Changes

### [Component Name] [GestureWeb Frontend]

#### [MODIFY] [DetailModal.css](file:///c:/Users/User/Desktop/MERN/PROJECTS/GestureWeb/frontend/src/components/DetailModal.css)
- **.modal-overlay**:
    - Remove `overflow-y: auto`.
    - Set `overflow: hidden` to prevent the overlay from scrolling.
- **.modal-content**:
    - Add `max-height: 85vh` (or similar) to ensure the modal stays within the viewport.
    - Add `overflow-y: auto` to enable internal scrolling.
    - Add custom scrollbar styling for a premium look that matches the site's aesthetic.

## Verification Plan

### Manual Verification
- Open a modal with long content (e.g., a project with a long description).
- Verify that the modal content box is scrollable and the overlay/background remains fixed.
- Verify that the modal remains centered in the viewport.
- Check responsiveness on smaller screens to ensure the `max-height` works correctly.
